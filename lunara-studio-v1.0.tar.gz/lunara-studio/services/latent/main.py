"""
Lunara Studio · Latent Service
Embedding sidecar — provides image/text embeddings for continuity.
Free, self-hostable. Uses mock embeddings by default, can point to CLIP model.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, hashlib, logging, math, random
from typing import List, Optional

logging.basicConfig(level=os.getenv("LOG_LEVEL","info").upper())
log = logging.getLogger("latent")

app = FastAPI(title="Lunara Latent", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL_DIR = os.environ.get("MODEL_DIR", "/models")
USE_REAL_MODEL = os.environ.get("USE_CLIP", "false").lower() == "true"

# Try load CLIP if requested and available
clip_model = None
clip_processor = None
if USE_REAL_MODEL:
    try:
        from transformers import CLIPProcessor, CLIPModel
        clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32", cache_dir=MODEL_DIR)
        clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32", cache_dir=MODEL_DIR)
        log.info("CLIP model loaded")
    except Exception as e:
        log.warning(f"CLIP load failed, using mock: {e}")
        clip_model = None

class EmbedReq(BaseModel):
    url: Optional[str] = None
    text: Optional[str] = None
    kind: str = "image"  # image | text

class EmbedBatchReq(BaseModel):
    urls: List[str] = []
    texts: List[str] = []

def mock_vector(seed: str, dim: int = 512) -> List[float]:
    h = hashlib.sha256(seed.encode()).hexdigest()
    rnd = random.Random(h)
    # deterministic pseudo-embedding
    vec = [rnd.uniform(-1,1) for _ in range(dim)]
    # normalize
    norm = math.sqrt(sum(x*x for x in vec))
    if norm>0:
        vec = [x/norm for x in vec]
    return vec

@app.post("/embed")
async def embed(req: EmbedReq):
    seed = req.url or req.text or "empty"
    if clip_model and req.text:
        try:
            import torch
            inputs = clip_processor(text=[req.text], return_tensors="pt", padding=True)
            with torch.no_grad():
                feats = clip_model.get_text_features(**inputs)
                vec = feats[0].tolist()
                return {"vector": vec, "model": "clip-vit-b-32", "seed": seed}
        except Exception as e:
            log.warning(f"clip text embed failed: {e}")
    if clip_model and req.url and not req.url.startswith("mock://") and not req.url.startswith("data:"):
        try:
            import httpx, torch
            from PIL import Image
            import io
            # download image
            async with httpx.AsyncClient(timeout=20) as c:
                r = await c.get(req.url)
                r.raise_for_status()
                img = Image.open(io.BytesIO(r.content)).convert("RGB")
            inputs = clip_processor(images=img, return_tensors="pt")
            import torch
            with torch.no_grad():
                feats = clip_model.get_image_features(**inputs)
                vec = feats[0].tolist()
                return {"vector": vec, "model": "clip-vit-b-32", "seed": seed}
        except Exception as e:
            log.warning(f"clip image embed failed: {e}")

    # mock fallback - 512 dim like CLIP
    vec = mock_vector(seed, dim=512)
    return {"vector": vec, "embedding": vec, "model": "mock-512", "seed": seed, "mock": True}

@app.post("/embed-batch")
async def embed_batch(req: EmbedBatchReq):
    vectors = []
    for u in req.urls:
        v = mock_vector(u, dim=512)
        vectors.append({"url": u, "vector": v})
    for t in req.texts:
        v = mock_vector(t, dim=512)
        vectors.append({"text": t, "vector": v})
    return {"vectors": vectors, "model": "mock-512"}

@app.post("/similarity")
async def similarity(payload: dict):
    """Compute cosine similarity between two urls/texts."""
    a = payload.get("a")
    b = payload.get("b")
    if not a or not b:
        return {"error": "need a and b"}
    va = mock_vector(a, dim=512)
    vb = mock_vector(b, dim=512)
    dot = sum(x*y for x,y in zip(va,vb))
    return {"a": a, "b": b, "similarity": dot, "distance": math.sqrt(sum((x-y)**2 for x,y in zip(va,vb)))}

@app.get("/health")
async def health():
    return {"ok": True, "service": "latent", "version": "1.0.0", "model": "clip-vit-b-32" if clip_model else "mock-512", "model_dir": MODEL_DIR}

"""
Lunara Studio · Asset Service
Content-addressable storage backed by MinIO (S3 compatible).
Falls back to local filesystem when MinIO unavailable.
"""
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import os, hashlib, logging, io, pathlib, uuid
from datetime import datetime, timezone

logging.basicConfig(level=os.getenv("LOG_LEVEL", "info").upper())
log = logging.getLogger("asset")

app = FastAPI(title="Lunara Asset", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MINIO_ENDPOINT = os.environ.get("MINIO_ENDPOINT", "minio:9000")
MINIO_ACCESS = os.environ.get("MINIO_ACCESS_KEY", "lunara")
MINIO_SECRET = os.environ.get("MINIO_SECRET_KEY", "lunara123")
MINIO_BUCKET = os.environ.get("MINIO_BUCKET", "lunara-assets")
MINIO_SECURE = os.environ.get("MINIO_SECURE", "false").lower() == "true"

LOCAL_STORE = pathlib.Path(os.environ.get("LOCAL_STORE", "/tmp/lunara_assets"))
LOCAL_STORE.mkdir(parents=True, exist_ok=True)

minio_client = None
try:
    from minio import Minio
    minio_client = Minio(
        MINIO_ENDPOINT,
        access_key=MINIO_ACCESS,
        secret_key=MINIO_SECRET,
        secure=MINIO_SECURE
    )
    # ensure bucket
    if not minio_client.bucket_exists(MINIO_BUCKET):
        minio_client.make_bucket(MINIO_BUCKET)
        log.info(f"created bucket {MINIO_BUCKET}")
except Exception as e:
    log.warning(f"MinIO unavailable, using local fallback: {e}")
    minio_client = None

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    data = await file.read()
    h = sha256_bytes(data)
    ext = pathlib.Path(file.filename or "bin").suffix or ".bin"
    key = f"{h[:2]}/{h[2:4]}/{h}{ext}"

    # Try MinIO
    if minio_client:
        try:
            minio_client.put_object(MINIO_BUCKET, key, io.BytesIO(data), len(data), content_type=file.content_type or "application/octet-stream")
            url = f"http://{MINIO_ENDPOINT}/{MINIO_BUCKET}/{key}" if not MINIO_SECURE else f"https://{MINIO_ENDPOINT}/{MINIO_BUCKET}/{key}"
            # Also return internal url via asset service for proxying
            internal_url = f"/assets/{h}"
            return {
                "hash": h,
                "url": internal_url,
                "storage_url": url,
                "size": len(data),
                "mime": file.content_type,
                "key": key
            }
        except Exception as e:
            log.warning(f"MinIO put failed, fallback to local: {e}")

    # Local fallback
    local_path = LOCAL_STORE / key
    local_path.parent.mkdir(parents=True, exist_ok=True)
    local_path.write_bytes(data)
    return {
        "hash": h,
        "url": f"/assets/{h}",
        "storage_url": str(local_path),
        "size": len(data),
        "mime": file.content_type,
        "key": key
    }

@app.get("/assets/{hash}")
async def get_asset(hash: str):
    # Try to find file by hash prefix
    # First check local store recursively
    for p in LOCAL_STORE.rglob(f"{hash}*"):
        if p.is_file():
            def iterfile():
                with open(p, "rb") as f:
                    yield from f
            return StreamingResponse(iterfile(), media_type="application/octet-stream")
    # Try MinIO listing
    if minio_client:
        try:
            # list objects with prefix
            objs = minio_client.list_objects(MINIO_BUCKET, prefix=f"{hash[:2]}/{hash[2:4]}/{hash}", recursive=True)
            for obj in objs:
                data = minio_client.get_object(MINIO_BUCKET, obj.object_name)
                return StreamingResponse(data.stream(32*1024), media_type="application/octet-stream")
        except Exception as e:
            log.warning(f"MinIO get failed: {e}")
    raise HTTPException(404, "Asset not found")

@app.post("/store")
async def store_from_url(payload: dict):
    """Store asset from external URL or mock url into CAS."""
    import httpx
    url = payload.get("url")
    if not url:
        raise HTTPException(400, "url required")
    if url.startswith("mock://"):
        # generate placeholder bytes for mock
        content = f"MOCK ASSET {url}".encode()
        h = sha256_bytes(content)
        key = f"{h[:2]}/{h[2:4]}/{h}.bin"
        local_path = LOCAL_STORE / key
        local_path.parent.mkdir(parents=True, exist_ok=True)
        local_path.write_bytes(content)
        return {"hash": h, "url": f"/assets/{h}", "original_url": url, "mock": True}
    # try download
    try:
        async with httpx.AsyncClient(timeout=60, follow_redirects=True) as c:
            r = await c.get(url)
            r.raise_for_status()
            data = r.content
            h = sha256_bytes(data)
            key = f"{h[:2]}/{h[2:4]}/{h}.bin"
            if minio_client:
                try:
                    minio_client.put_object(MINIO_BUCKET, key, io.BytesIO(data), len(data))
                except Exception as e:
                    log.warning(f"MinIO put failed: {e}")
                    local_path = LOCAL_STORE / key
                    local_path.parent.mkdir(parents=True, exist_ok=True)
                    local_path.write_bytes(data)
            else:
                local_path = LOCAL_STORE / key
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_bytes(data)
            return {"hash": h, "url": f"/assets/{h}", "original_url": url, "size": len(data)}
    except Exception as e:
        log.exception("store from url failed")
        raise HTTPException(500, str(e))

@app.get("/health")
async def health():
    return {"ok": True, "service": "asset", "version": "1.0.0", "minio": bool(minio_client), "local_store": str(LOCAL_STORE)}

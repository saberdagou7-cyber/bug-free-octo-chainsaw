from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, logging, sys

logging.basicConfig(level=os.getenv("LOG_LEVEL","info").upper())
log = logging.getLogger("repaint")
sys.path.insert(0, "/app/packages/shared")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../packages/shared"))

app = FastAPI(title="Lunara Repaint", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

ADAPTER_NAME = os.environ.get("ADAPTER", os.environ.get("REPAINT_ADAPTER","mock")).lower()

def get_adapter(name: str):
    if "sdxl" in name:
        from adapters.sdxl_img2img import SDXLImg2ImgAdapter
        return SDXLImg2ImgAdapter()
    else:
        from adapters.mock import MockAdapter
        return MockAdapter()

adapter = get_adapter(ADAPTER_NAME)
log.info(f"Repaint adapter: {adapter.name}")

class RepaintReq(BaseModel):
    image_url: str
    prompt: str
    mask_url: str | None = None
    strength: float = 0.7

@app.post("/repaint")
async def repaint(req: RepaintReq):
    try:
        result = await adapter.repaint(req.image_url, req.prompt, req.mask_url, req.strength)
        return {"adapter": adapter.name, "result": result.model_dump()}
    except Exception as e:
        log.exception("repaint failed")
        raise HTTPException(500, str(e))

@app.get("/health")
async def health():
    return {"ok": True, "service": "repaint", "version": "1.0.0", "adapter": adapter.name}

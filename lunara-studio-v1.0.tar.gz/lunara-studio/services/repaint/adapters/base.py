from abc import ABC, abstractmethod
class RepaintAdapter(ABC):
    name = "base"
    @property
    @abstractmethod
    def capabilities(self): pass
    @abstractmethod
    async def repaint(self, image_url: str, prompt: str, mask_url: str | None = None, strength: float = 0.7, **kwargs): pass

import hashlib, io, base64
from PIL import Image
from .base import RepaintAdapter

class MockAdapter(RepaintAdapter):
    name = "mock"
    @property
    def capabilities(self):
        from lunara_contracts import AdapterCapabilities
        return AdapterCapabilities(name="mock", resolutions=["1024x576"], aspect_ratios=["16:9"], pricing_per_second_usd=0.0)
    async def repaint(self, image_url: str, prompt: str, mask_url: str | None = None, strength: float = 0.7, **kwargs):
        from lunara_contracts import GenerationResult
        import uuid
        h = hashlib.sha256(f"{image_url}:{prompt}:{strength}".encode()).hexdigest()
        # Create a tinted image as mock repaint
        r = int(h[0:2],16); g=int(h[2:4],16); b=int(h[4:6],16)
        img = Image.new("RGB", (1024,576), (r,g,b))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        data_url = f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}"
        return GenerationResult(url=data_url, kind="image", resolution="1024x576", adapter_name="mock", external_job_id=str(uuid.uuid4()), metadata={"prompt": prompt, "source": image_url})

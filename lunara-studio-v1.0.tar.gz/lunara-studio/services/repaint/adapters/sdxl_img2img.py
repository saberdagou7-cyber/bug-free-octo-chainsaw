import os, httpx
from .base import RepaintAdapter

class SDXLImg2ImgAdapter(RepaintAdapter):
    name = "sdxl-img2img"
    def __init__(self):
        self.api_url = os.environ.get("SDXL_API_URL", "http://localhost:8188")
    @property
    def capabilities(self):
        from lunara_contracts import AdapterCapabilities
        return AdapterCapabilities(name="sdxl-img2img", resolutions=["1024x576","1920x1080"], aspect_ratios=["16:9","2.39:1"], pricing_per_second_usd=0.0, typical_latency_seconds=5.0)
    async def repaint(self, image_url: str, prompt: str, mask_url: str | None = None, strength: float = 0.7, **kwargs):
        from lunara_contracts import GenerationResult
        import uuid
        payload = {"prompt": prompt, "image": image_url, "strength": strength, "mask": mask_url}
        try:
            async with httpx.AsyncClient(timeout=300) as c:
                r = await c.post(f"{self.api_url}/img2img", json=payload)
                r.raise_for_status()
                d = r.json()
                url = d.get("image_url") or d.get("url") or d["images"][0]["url"]
                return GenerationResult(url=url, kind="image", adapter_name="sdxl-img2img", external_job_id=d.get("job_id", str(uuid.uuid4())))
        except Exception as e:
            print(f"SDXL img2img failed {e}, fallback mock")
            from .mock import MockAdapter
            return await MockAdapter().repaint(image_url, prompt, mask_url, strength, **kwargs)

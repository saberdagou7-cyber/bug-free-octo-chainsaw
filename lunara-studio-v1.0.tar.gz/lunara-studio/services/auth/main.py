"""
Lunara Studio · Auth Service
JWT auth with Postgres. Free, self-hostable.
"""
from __future__ import annotations
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import os, uuid, logging, asyncpg
from datetime import datetime, timedelta, timezone
from jose import jwt
from passlib.context import CryptContext

logging.basicConfig(level=os.getenv("LOG_LEVEL", "info").upper())
log = logging.getLogger("auth")

app = FastAPI(title="Lunara Auth", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DATABASE_URL = (
    f"postgresql://{os.environ.get('POSTGRES_USER','lunara')}:{os.environ.get('POSTGRES_PASSWORD','lunara')}"
    f"@{os.environ.get('POSTGRES_HOST','postgres')}:{os.environ.get('POSTGRES_PORT','5432')}/{os.environ.get('POSTGRES_DB','lunara')}"
)
JWT_SECRET = os.environ.get("JWT_SECRET", "dev-secret-change-me-32-chars-min")
JWT_ALG = "HS256"
JWT_EXPIRE_HOURS = 24*7

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer = HTTPBearer(auto_error=False)
pool: asyncpg.Pool | None = None

@app.on_event("startup")
async def startup():
    global pool
    for i in range(30):
        try:
            pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=10)
            log.info("connected to postgres")
            break
        except Exception as e:
            log.warning(f"postgres not ready, retry {i}: {e}")
            import asyncio; await asyncio.sleep(2)
    if not pool:
        log.error("failed to connect to postgres, running in mock mode")

@app.on_event("shutdown")
async def shutdown():
    if pool:
        await pool.close()

class RegisterReq(BaseModel):
    email: str
    password: str
    display_name: str | None = None

class LoginReq(BaseModel):
    email: str
    password: str

def make_token(user_id: str, email: str):
    exp = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRE_HOURS)
    payload = {"sub": user_id, "email": email, "exp": exp}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

async def get_current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)):
    if not creds:
        # Allow anonymous demo user for mock mode
        return {"id": "00000000-0000-0000-0000-000000000001", "email": "demo@lunara.studio"}
    try:
        data = jwt.decode(creds.credentials, JWT_SECRET, algorithms=[JWT_ALG])
        return {"id": data["sub"], "email": data["email"]}
    except Exception:
        raise HTTPException(401, "Invalid token")

@app.post("/register")
async def register(req: RegisterReq):
    if not pool:
        return {"id": str(uuid.uuid4()), "email": req.email, "token": make_token(str(uuid.uuid4()), req.email)}
    hashed = pwd_ctx.hash(req.password)
    try:
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "INSERT INTO users (email, password_hash, display_name) VALUES ($1,$2,$3) RETURNING id",
                req.email, hashed, req.display_name or req.email.split("@")[0]
            )
            uid = str(row["id"])
            return {"id": uid, "email": req.email, "token": make_token(uid, req.email)}
    except asyncpg.UniqueViolationError:
        raise HTTPException(400, "Email already registered")
    except Exception as e:
        log.exception("register failed")
        raise HTTPException(500, str(e))

@app.post("/login")
async def login(req: LoginReq):
    if not pool:
        return {"id": "00000000-0000-0000-0000-000000000001", "email": req.email, "token": make_token("00000000-0000-0000-0000-000000000001", req.email)}
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT id, password_hash, email FROM users WHERE email=$1", req.email)
        if not row:
            raise HTTPException(401, "Invalid credentials")
        # asyncpg with pgcrypto crypt: check via SQL
        valid = await conn.fetchval("SELECT (crypt($1, $2) = $2)", req.password, row["password_hash"])
        # fallback to passlib if pgcrypto check fails
        if not valid:
            try:
                if not pwd_ctx.verify(req.password, row["password_hash"]):
                    raise HTTPException(401, "Invalid credentials")
            except Exception:
                # if hash is pgcrypto and passlib fails, try crypt again
                if not valid:
                    raise HTTPException(401, "Invalid credentials")
        uid = str(row["id"])
        return {"id": uid, "email": row["email"], "token": make_token(uid, row["email"])}

@app.get("/me")
async def me(user=Depends(get_current_user)):
    return user

@app.get("/health")
async def health():
    return {"ok": True, "service": "auth", "version": "1.0.0", "db": bool(pool)}

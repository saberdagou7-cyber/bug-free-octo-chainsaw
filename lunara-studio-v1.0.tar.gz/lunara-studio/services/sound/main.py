"""
Lunara Studio · Sound Service (v2.0)
Free, open-source TTS and music generation.

Adapters:
  - qwen3-tts: voice cloning (Apache 2.0)
  - ace-step:  music generation (open source)
  - mock:      smoke-testing

This service is NOT in the per-panel generation path.
It runs at final mix, for:
  - Dialogue replacement / re-recording
  - Score generation
  - Foley layering
"""
from __future__ import annotations
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import os, uuid, asyncio, hashlib, httpx, logging
from datetime import datetime, timezone

logging.basicConfig(level=os.getenv("LOG_LEVEL", "info").upper())
log = logging.getLogger("sound")

app = FastAPI(title="Lunara Sound", version="2.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"],
    allow_methods=["*"], allow_headers=["*"],
)

QWEN3_TTS_URL = os.environ.get("QWEN3_TTS_URL", "http://localhost:8191")
ACE_STEP_URL = os.environ.get("ACE_STEP_URL", "http://localhost:8192")


class SoundRequest(BaseModel):
    kind: str = Field(..., pattern="^(dialogue|ambience|foley|score)$")
    prompt: str
    duration_ms: int = Field(..., ge=100, le=600_000)
    voice_id: str | None = None
    reference_audio_url: str | None = None  # for voice cloning
    mode: str | None = None


async def qwen3_tts_generate(req: SoundRequest):
    """Qwen3-TTS: 3-second voice cloning, Apache 2.0."""
    payload = {
        "text": req.prompt,
        "voice_id": req.voice_id or "default",
        "reference_audio": req.reference_audio_url,
        "sample_rate": 48000,
    }
    try:
        async with httpx.AsyncClient(timeout=180) as c:
            r = await c.post(f"{QWEN3_TTS_URL}/generate", json=payload)
            r.raise_for_status()
            d = r.json()
            return {
                "url": d["audio_url"],
                "kind": "dialogue",
                "durationMs": req.duration_ms,
                "adapter": "qwen3-tts",
            }
    except Exception as e:
        log.warning(f"Qwen3-TTS unavailable {QWEN3_TTS_URL}: {e}, fallback mock")
        return await mock_generate(req)


async def ace_step_generate(req: SoundRequest):
    """ACE-Step 1.5: music generation, runs on consumer GPUs."""
    payload = {
        "prompt": req.prompt,
        "duration": req.duration_ms / 1000.0,
        "genre": req.mode or "cinematic",
    }
    try:
        async with httpx.AsyncClient(timeout=300) as c:
            r = await c.post(f"{ACE_STEP_URL}/generate", json=payload)
            r.raise_for_status()
            d = r.json()
            return {
                "url": d["audio_url"],
                "kind": req.kind,
                "durationMs": req.duration_ms,
                "adapter": "ace-step",
            }
    except Exception as e:
        log.warning(f"ACE-Step unavailable {ACE_STEP_URL}: {e}, fallback mock")
        return await mock_generate(req)


async def mock_generate(req: SoundRequest):
    await asyncio.sleep(0.3)
    h = hashlib.sha1(f"{req.kind}:{req.prompt}".encode()).hexdigest()[:16]
    return {
        "url": f"mock://sound/{h}.wav",
        "kind": req.kind,
        "durationMs": req.duration_ms,
        "adapter": "mock",
    }


@app.post("/generate")
async def generate(req: SoundRequest):
    adapter = os.environ.get("SOUND_ADAPTER", os.environ.get("ADAPTER", "mock")).lower()
    try:
        if adapter == "qwen3-tts" and req.kind == "dialogue":
            result = await qwen3_tts_generate(req)
        elif adapter == "ace-step" and req.kind == "score":
            result = await ace_step_generate(req)
        else:
            # smart routing: dialogue -> qwen, score -> ace, else mock
            if req.kind == "dialogue" and os.environ.get("QWEN3_TTS_URL"):
                try:
                    result = await qwen3_tts_generate(req)
                except Exception:
                    result = await mock_generate(req)
            elif req.kind == "score" and os.environ.get("ACE_STEP_URL"):
                try:
                    result = await ace_step_generate(req)
                except Exception:
                    result = await mock_generate(req)
            else:
                result = await mock_generate(req)
    except Exception as e:
        log.exception("sound failed")
        raise HTTPException(500, str(e))
    return {
        "jobId": str(uuid.uuid4()),
        "status": "completed",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "result": result,
    }


@app.get("/health")
async def health():
    return {
        "ok": True,
        "service": "sound",
        "version": "2.0.0",
        "adapter": os.environ.get("SOUND_ADAPTER", "mock"),
    }

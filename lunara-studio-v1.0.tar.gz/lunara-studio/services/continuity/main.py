"""
Lunara Studio · Continuity Service
Checks visual continuity between panels using latent embeddings.
Free, self-hostable, no paid APIs.
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, logging, hashlib, math, random
import asyncpg
from typing import List, Optional

logging.basicConfig(level=os.getenv("LOG_LEVEL","info").upper())
log = logging.getLogger("continuity")

app = FastAPI(title="Lunara Continuity", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DATABASE_URL = (
    f"postgresql://{os.environ.get('POSTGRES_USER','lunara')}:{os.environ.get('POSTGRES_PASSWORD','lunara')}"
    f"@{os.environ.get('POSTGRES_HOST','postgres')}:{os.environ.get('POSTGRES_PORT','5432')}/{os.environ.get('POSTGRES_DB','lunara')}"
)
pool: asyncpg.Pool | None = None
LATENT_URL = os.environ.get("LATENT_URL", "http://latent:8000")

@app.on_event("startup")
async def startup():
    global pool
    for i in range(20):
        try:
            pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=5)
            log.info("connected to postgres")
            break
        except Exception as e:
            log.warning(f"postgres not ready retry {i}: {e}")
            import asyncio; await asyncio.sleep(2)

@app.on_event("shutdown")
async def shutdown():
    if pool:
        await pool.close()

class ContinuityCheckReq(BaseModel):
    panel_id: str
    reference_panel_ids: List[str] = []
    keyframe_url: str
    reference_urls: List[str] = []
    threshold: float = 0.75

class ContinuityBatchReq(BaseModel):
    project_id: str
    threshold: float = 0.75

def mock_embedding(url: str) -> List[float]:
    """Deterministic mock embedding from URL hash."""
    h = hashlib.sha256(url.encode()).hexdigest()
    # 16-dim vector from hash
    vec = []
    for i in range(0, 32, 2):
        vec.append(int(h[i:i+2], 16) / 255.0)
    # pad to 32 dims with pseudo-random derived from hash
    rnd = random.Random(h)
    while len(vec) < 32:
        vec.append(rnd.random())
    return vec

def cosine_similarity(a: List[float], b: List[float]) -> float:
    dot = sum(x*y for x,y in zip(a,b))
    norm_a = math.sqrt(sum(x*x for x in a))
    norm_b = math.sqrt(sum(y*y for y in b))
    if norm_a==0 or norm_b==0:
        return 0.0
    return dot/(norm_a*norm_b)

def euclidean_distance(a: List[float], b: List[float]) -> float:
    return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))

async def get_embedding(url: str) -> List[float]:
    """Try latent service, fallback to mock."""
    import httpx
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.post(f"{LATENT_URL}/embed", json={"url": url, "kind": "image"})
            if r.status_code == 200:
                data = r.json()
                return data.get("vector") or data.get("embedding") or mock_embedding(url)
    except Exception as e:
        log.debug(f"latent unavailable: {e}")
    return mock_embedding(url)

@app.post("/check")
async def check_continuity(req: ContinuityCheckReq):
    try:
        # get embeddings
        target_emb = await get_embedding(req.keyframe_url)
        issues = []
        scores = []
        for ref_url in req.reference_urls:
            ref_emb = await get_embedding(ref_url)
            sim = cosine_similarity(target_emb, ref_emb)
            dist = euclidean_distance(target_emb, ref_emb)
            scores.append({"ref_url": ref_url, "similarity": sim, "distance": dist})
            if sim < req.threshold:
                issues.append(f"Low similarity {sim:.2f} vs reference {ref_url[:40]}")

        avg_sim = sum(s["similarity"] for s in scores)/len(scores) if scores else 1.0
        avg_dist = sum(s["distance"] for s in scores)/len(scores) if scores else 0.0
        passed = avg_sim >= req.threshold

        # store in DB if available
        if pool and req.reference_panel_ids:
            try:
                async with pool.acquire() as conn:
                    for ref_id in req.reference_panel_ids:
                        # try uuid
                        try:
                            import uuid
                            pid = uuid.UUID(req.panel_id) if len(req.panel_id)>20 else None
                            rid = uuid.UUID(ref_id) if len(ref_id)>20 else None
                            if pid and rid:
                                await conn.execute(
                                    "INSERT INTO continuity_scores (panel_id, reference_panel_id, score, embedding_distance, issues, passed) VALUES ($1,$2,$3,$4,$5,$6)",
                                    pid, rid, avg_sim, avg_dist, str(issues), passed
                                )
                        except Exception:
                            pass
            except Exception as e:
                log.warning(f"failed to store continuity score: {e}")

        return {
            "panel_id": req.panel_id,
            "score": avg_sim,
            "distance": avg_dist,
            "passed": passed,
            "threshold": req.threshold,
            "issues": issues,
            "details": scores
        }
    except Exception as e:
        log.exception("continuity check failed")
        raise HTTPException(500, str(e))

@app.post("/check-project/{project_id}")
async def check_project(project_id: str, threshold: float = 0.75):
    """Batch check all panels in a project for continuity drift."""
    if not pool:
        return {"project_id": project_id, "checks": [], "mock": True, "message": "No DB, mock mode"}
    import uuid, json
    try:
        pid = uuid.UUID(project_id) if project_id != "demo" else uuid.UUID("00000000-0000-0000-0000-000000000010")
    except Exception:
        raise HTTPException(400, "Invalid project id")
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT id, ordinal, keyframe_url FROM panels WHERE project_id=$1 AND keyframe_url IS NOT NULL ORDER BY ordinal", pid)
        if not rows:
            return {"project_id": project_id, "checks": [], "message": "No keyframed panels"}
        checks = []
        prev_url = None
        prev_id = None
        for r in rows:
            if prev_url and r["keyframe_url"]:
                # check continuity vs previous
                emb_curr = await get_embedding(r["keyframe_url"])
                emb_prev = await get_embedding(prev_url)
                sim = cosine_similarity(emb_curr, emb_prev)
                checks.append({
                    "panel_id": str(r["id"]),
                    "ordinal": r["ordinal"],
                    "reference_panel_id": str(prev_id),
                    "similarity": sim,
                    "passed": sim >= threshold
                })
            prev_url = r["keyframe_url"]
            prev_id = r["id"]
        return {"project_id": project_id, "checks": checks, "average": sum(c["similarity"] for c in checks)/len(checks) if checks else 1.0}

@app.get("/health")
async def health():
    return {"ok": True, "service": "continuity", "version": "1.0.0", "db": bool(pool)}

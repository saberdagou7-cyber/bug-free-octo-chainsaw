"""
Lunara Studio · Film Service
Pipeline orchestrator — coordinates canvas -> repaint -> av_motion -> sound -> render.
Free, self-hostable, mock-friendly.
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, logging, uuid, asyncio, json
import httpx
from datetime import datetime, timezone
from typing import List, Optional

logging.basicConfig(level=os.getenv("LOG_LEVEL","info").upper())
log = logging.getLogger("film")

app = FastAPI(title="Lunara Film", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

CANVAS_URL = os.environ.get("CANVAS_URL", "http://canvas:8000")
REPAINT_URL = os.environ.get("REPAINT_URL", "http://repaint:8000")
AV_MOTION_URL = os.environ.get("AV_MOTION_URL", "http://av_motion:8000")
SOUND_URL = os.environ.get("SOUND_URL", "http://sound:8000")
LATENT_URL = os.environ.get("LATENT_URL", "http://latent:8000")
CONTINUITY_URL = os.environ.get("CONTINUITY_URL", "http://continuity:8000")
PROJECT_URL = os.environ.get("PROJECT_URL", "http://project:8000")
RENDER_URL = os.environ.get("RENDER_URL", "http://render:8000")

# In-memory job store for mock mode
JOBS = {}

class PipelineRunReq(BaseModel):
    project_id: str
    panel_ids: Optional[List[str]] = None  # if None, run all
    steps: List[str] = ["canvas", "motion"]  # canvas, repaint, motion, sound, render
    canvas_variants: int = 1
    motion_camera: str = "static"
    resolution: str = "720p"
    frame_rate: int = 24

class PipelineStatusReq(BaseModel):
    job_id: str

async def call_service(url: str, payload: dict, timeout: int = 120):
    async with httpx.AsyncClient(timeout=timeout) as c:
        try:
            r = await c.post(url, json=payload)
            r.raise_for_status()
            return r.json()
        except httpx.HTTPStatusError as e:
            log.warning(f"service {url} returned {e.response.status_code}: {e.response.text[:500]}")
            raise
        except Exception as e:
            log.warning(f"service {url} failed: {e}")
            raise

async def run_pipeline(job_id: str, req: PipelineRunReq):
    JOBS[job_id]["status"] = "running"
    JOBS[job_id]["started_at"] = datetime.now(timezone.utc).isoformat()
    results = []
    try:
        # 1. Get panels
        project_id = req.project_id
        if project_id == "demo":
            project_id = "00000000-0000-0000-0000-000000000010"
        # fetch panels from project service
        panels = []
        try:
            async with httpx.AsyncClient(timeout=30) as c:
                r = await c.get(f"{PROJECT_URL}/projects/{project_id}/panels")
                r.raise_for_status()
                data = r.json()
                panels = data.get("panels", [])
        except Exception as e:
            log.warning(f"project service unavailable, using mock panels: {e}")
            # mock panels
            panels = [{"id": f"mock-{i}", "ordinal": i, "prompt": f"Panel {i} prompt", "motion_prompt": "slow push in", "slug": f"p{i}"} for i in range(1,4)]

        if req.panel_ids:
            panels = [p for p in panels if p.get("id") in req.panel_ids or p.get("panelId") in req.panel_ids]

        JOBS[job_id]["total_panels"] = len(panels)
        log.info(f"pipeline {job_id}: {len(panels)} panels, steps {req.steps}")

        for idx, panel in enumerate(panels):
            panel_result = {"panel_id": panel.get("id"), "ordinal": panel.get("ordinal", idx), "steps": {}}
            JOBS[job_id]["current_panel"] = idx+1
            JOBS[job_id]["current_panel_id"] = panel.get("id")

            # CANVAS
            if "canvas" in req.steps:
                try:
                    canvas_payload = {
                        "prompt": panel.get("prompt", ""),
                        "negative_prompt": panel.get("negative_prompt", ""),
                        "variants": req.canvas_variants,
                        "width": 1024 if req.resolution=="720p" else 1920,
                        "height": 576 if req.resolution=="720p" else 1080
                    }
                    data = await call_service(f"{CANVAS_URL}/generate", canvas_payload)
                    panel_result["steps"]["canvas"] = data
                    # pick first variant as keyframe
                    variants = data.get("variants", [])
                    if variants:
                        panel["keyframe_url"] = variants[0].get("url")
                except Exception as e:
                    panel_result["steps"]["canvas"] = {"error": str(e)}
                    log.warning(f"canvas failed for panel {panel.get('id')}: {e}")

            # REPAINT (optional)
            if "repaint" in req.steps and panel.get("keyframe_url"):
                try:
                    repaint_payload = {
                        "image_url": panel.get("keyframe_url"),
                        "prompt": panel.get("prompt", "") + " enhanced detail",
                        "strength": 0.5
                    }
                    data = await call_service(f"{REPAINT_URL}/repaint", repaint_payload)
                    panel_result["steps"]["repaint"] = data
                    if data.get("result", {}).get("url"):
                        panel["keyframe_url"] = data["result"]["url"]
                except Exception as e:
                    panel_result["steps"]["repaint"] = {"error": str(e)}

            # MOTION
            if "motion" in req.steps and panel.get("keyframe_url"):
                try:
                    motion_payload = {
                        "source_url": panel.get("keyframe_url"),
                        "motion_prompt": panel.get("motion_prompt", "subtle motion, cinematic"),
                        "camera_movement": panel.get("camera", req.motion_camera),
                        "duration": panel.get("duration_seconds", 3.0),
                        "resolution": req.resolution,
                        "aspect_ratio": "16:9",
                        "frame_rate": req.frame_rate,
                        "audio_prompt": None,
                        "reference_stack": panel.get("reference_stack", [])
                    }
                    data = await call_service(f"{AV_MOTION_URL}/generate", motion_payload, timeout=300)
                    panel_result["steps"]["motion"] = data
                    if data.get("result", {}).get("url"):
                        panel["video_url"] = data["result"]["url"]
                except Exception as e:
                    panel_result["steps"]["motion"] = {"error": str(e)}
                    log.warning(f"motion failed for panel {panel.get('id')}: {e}")

            # SOUND (optional)
            if "sound" in req.steps:
                try:
                    # generate ambience for panel
                    sound_payload = {
                        "kind": "ambience",
                        "prompt": f"{panel.get('prompt','')} ambient sound, cinematic",
                        "duration_ms": int(panel.get("duration_seconds", 3.0)*1000)
                    }
                    data = await call_service(f"{SOUND_URL}/generate", sound_payload)
                    panel_result["steps"]["sound"] = data
                except Exception as e:
                    panel_result["steps"]["sound"] = {"error": str(e)}

            results.append(panel_result)
            JOBS[job_id]["completed_panels"] = idx+1
            JOBS[job_id]["results"] = results

        # RENDER (optional final assembly)
        if "render" in req.steps:
            try:
                manifest = []
                for p in panels:
                    if p.get("video_url"):
                        manifest.append({
                            "panel_id": p.get("id"),
                            "ordinal": p.get("ordinal", 0),
                            "video_url": p.get("video_url"),
                            "duration_seconds": p.get("duration_seconds", 3.0)
                        })
                if manifest:
                    render_payload = {
                        "project_id": project_id,
                        "manifest": manifest,
                        "output_format": "mp4",
                        "resolution": "1920x1080" if req.resolution!="720p" else "1280x720",
                        "frame_rate": req.frame_rate
                    }
                    data = await call_service(f"{RENDER_URL}/render", render_payload, timeout=300)
                    JOBS[job_id]["render"] = data
            except Exception as e:
                log.warning(f"render failed: {e}")
                JOBS[job_id]["render"] = {"error": str(e)}

        JOBS[job_id]["status"] = "completed"
        JOBS[job_id]["finished_at"] = datetime.now(timezone.utc).isoformat()
        log.info(f"pipeline {job_id} completed")
    except Exception as e:
        log.exception(f"pipeline {job_id} failed")
        JOBS[job_id]["status"] = "failed"
        JOBS[job_id]["error"] = str(e)
        JOBS[job_id]["finished_at"] = datetime.now(timezone.utc).isoformat()

@app.post("/pipeline/run")
async def pipeline_run(req: PipelineRunReq, bg: BackgroundTasks):
    job_id = str(uuid.uuid4())
    JOBS[job_id] = {
        "job_id": job_id,
        "project_id": req.project_id,
        "status": "queued",
        "steps": req.steps,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "total_panels": 0,
        "completed_panels": 0,
        "results": []
    }
    bg.add_task(run_pipeline, job_id, req)
    return {"jobId": job_id, "status": "queued", "project_id": req.project_id}

@app.get("/pipeline/{job_id}")
async def pipeline_status(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job

@app.get("/pipeline")
async def list_pipelines():
    return {"jobs": list(JOBS.values())[-20:]}

@app.get("/health")
async def health():
    return {"ok": True, "service": "film", "version": "1.0.0", "active_jobs": len([j for j in JOBS.values() if j["status"]=="running"])}

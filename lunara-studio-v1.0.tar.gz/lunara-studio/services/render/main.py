"""
Lunara Studio · Render Service
Assembles generated panels into a final master with FFmpeg.

Takes a manifest (from the Film service), concatenates video clips,
overlays audio, applies the film LUT, and outputs a single file.
"""
from __future__ import annotations
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, uuid, subprocess, tempfile, logging, httpx, pathlib
from datetime import datetime, timezone
from typing import List, Optional

logging.basicConfig(level=os.getenv("LOG_LEVEL", "info").upper())
log = logging.getLogger("render")

app = FastAPI(title="Lunara Render", version="1.0.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"],
    allow_methods=["*"], allow_headers=["*"],
)

OUTPUT_DIR = pathlib.Path(os.environ.get("OUTPUT_DIR", "/tmp/lunara_renders"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

class RenderRequest(BaseModel):
    project_id: str
    manifest: List[dict]
    output_format: str = "mp4"
    resolution: str = "1920x1080"
    frame_rate: int = 24
    lut_path: str | None = None
    include_audio: bool = True

async def _download(url: str, dest: str):
    if url.startswith("mock://"):
        # Create placeholder video file (black frame) using ffmpeg if available, else empty file
        try:
            # Generate 3 second black video with ffmpeg
            cmd = [
                "ffmpeg", "-y",
                "-f", "lavfi", "-i", f"color=c=black:s={dest}_res:d=3:r=24",
                "-c:v", "libx264", "-t", "3",
                dest
            ]
            # Actually simpler: create black video 1280x720
            # Use provided resolution via env? default 1280x720
            subprocess.run(
                ["ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=black:s=1280x720:d=3:r=24", "-c:v", "libx264", "-t", "3", dest],
                capture_output=True, timeout=30
            )
            if not pathlib.Path(dest).exists():
                pathlib.Path(dest).write_bytes(b"\x00" * 1024)
        except Exception as e:
            log.warning(f"ffmpeg mock gen failed {e}, writing empty")
            pathlib.Path(dest).write_bytes(b"\x00" * 1024)
        return
    if url.startswith("data:"):
        # data url - decode base64 image? treat as image, create video from it
        try:
            import base64
            header, b64data = url.split(",", 1)
            data = base64.b64decode(b64data)
            tmp_img = dest + ".png"
            pathlib.Path(tmp_img).write_bytes(data)
            # create 3s video from image
            subprocess.run(
                ["ffmpeg", "-y", "-loop", "1", "-i", tmp_img, "-c:v", "libx264", "-t", "3", "-pix_fmt", "yuv420p", dest],
                capture_output=True, timeout=30
            )
            pathlib.Path(tmp_img).unlink(missing_ok=True)
            return
        except Exception as e:
            log.warning(f"data url handling failed {e}")
            pathlib.Path(dest).write_bytes(b"\x00"*1024)
            return

    async with httpx.AsyncClient(timeout=600, follow_redirects=True) as c:
        async with c.stream("GET", url) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                async for chunk in r.aiter_bytes(1024 * 1024):
                    f.write(chunk)

async def _render(req: RenderRequest) -> str:
    with tempfile.TemporaryDirectory() as tmp:
        # Download all panel clips.
        clips = []
        for i, panel in enumerate(req.manifest):
            url = panel.get("video_url")
            if not url:
                continue
            dest = os.path.join(tmp, f"panel_{i:03d}.mp4")
            try:
                await _download(url, dest)
                if pathlib.Path(dest).exists() and pathlib.Path(dest).stat().st_size > 0:
                    clips.append(dest)
            except Exception as e:
                log.warning(f"failed to download {url}: {e}")
                continue

        if not clips:
            # If no downloadable clips, create a demo black video
            output = OUTPUT_DIR / f"{req.project_id}_{uuid.uuid4().hex[:8]}.mp4"
            try:
                subprocess.run(
                    ["ffmpeg", "-y", "-f", "lavfi", "-i", "color=c=black:s=1280x720:d=5:r=24", "-c:v", "libx264", "-t", "5", str(output)],
                    capture_output=True, timeout=30
                )
            except Exception:
                output.write_bytes(b"\x00"*1024)
            return str(output)

        # Write the concat list.
        concat_path = os.path.join(tmp, "concat.txt")
        with open(concat_path, "w") as f:
            for clip in clips:
                f.write(f"file '{clip}'\n")

        # Concatenate.
        output = OUTPUT_DIR / f"{req.project_id}_{uuid.uuid4().hex[:8]}.{req.output_format}"
        ffmpeg_cmd = [
            "ffmpeg", "-y",
            "-f", "concat", "-safe", "0", "-i", concat_path,
            "-c", "copy",
            str(output),
        ]
        if req.lut_path and os.path.exists(req.lut_path):
            # Re-encode with LUT applied.
            ffmpeg_cmd = [
                "ffmpeg", "-y",
                "-f", "concat", "-safe", "0", "-i", concat_path,
                "-vf", f"lut3d={req.lut_path}",
                "-c:v", "libx264", "-preset", "slow", "-crf", "18",
                "-c:a", "aac", "-b:a", "320k",
                str(output),
            ]

        proc = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            log.warning(f"ffmpeg concat copy failed, trying re-encode: {proc.stderr[:1000]}")
            # Try re-encode fallback
            fallback_cmd = [
                "ffmpeg", "-y",
                "-f", "concat", "-safe", "0", "-i", concat_path,
                "-c:v", "libx264", "-preset", "fast", "-crf", "23",
                "-c:a", "aac",
                str(output)
            ]
            proc2 = subprocess.run(fallback_cmd, capture_output=True, text=True, timeout=300)
            if proc2.returncode != 0:
                log.error(f"ffmpeg fallback failed: {proc2.stderr[:2000]}")
                # Return whatever we have, or first clip
                if clips:
                    import shutil
                    shutil.copy(clips[0], str(output))
                else:
                    raise RuntimeError(f"ffmpeg failed: {proc.returncode} {proc.stderr[:500]}")

        # In production: upload the output to the asset service.
        return str(output)

@app.post("/render")
async def render(req: RenderRequest, bg: BackgroundTasks):
    job_id = str(uuid.uuid4())
    try:
        output = await _render(req)
    except Exception as e:
        log.exception("render failed")
        raise HTTPException(500, str(e))

    return {
        "jobId": job_id,
        "projectId": req.project_id,
        "status": "completed",
        "outputPath": output,
        "outputUrl": f"/renders/{pathlib.Path(output).name}",
        "createdAt": datetime.now(timezone.utc).isoformat(),
    }

@app.get("/renders/{name}")
async def get_render(name: str):
    from fastapi.responses import FileResponse
    fpath = OUTPUT_DIR / name
    if not fpath.exists():
        raise HTTPException(404, "Render not found")
    return FileResponse(str(fpath))

@app.get("/health")
async def health():
    # Check ffmpeg
    ffmpeg_ok = False
    try:
        r = subprocess.run(["ffmpeg", "-version"], capture_output=True, timeout=5)
        ffmpeg_ok = r.returncode == 0
    except Exception:
        pass
    return {"ok": True, "service": "render", "version": "1.0.0", "ffmpeg": ffmpeg_ok, "output_dir": str(OUTPUT_DIR)}

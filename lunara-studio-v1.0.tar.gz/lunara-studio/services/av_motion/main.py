"""
Lunara Studio · AV Motion Service
Joint audio-video generation via free adapters: mock, ltx-2.5, wan-2.2, minimax-h3
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, logging, sys

logging.basicConfig(level=os.getenv("LOG_LEVEL","info").upper())
log = logging.getLogger("av_motion")

sys.path.insert(0, "/app/packages/shared")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../packages/shared"))

app = FastAPI(title="Lunara AV Motion", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

ADAPTER_NAME = os.environ.get("ADAPTER", os.environ.get("MOTION_ADAPTER","mock")).lower()

def get_adapter(name: str):
    name = name.lower()
    if "ltx" in name:
        from adapters.ltx import LTXAdapter
        return LTXAdapter()
    elif "wan" in name:
        from adapters.wan import WanAdapter
        return WanAdapter()
    elif "minimax" in name or "h3" in name:
        from adapters.minimax_h3 import MiniMaxH3Adapter
        return MiniMaxH3Adapter()
    else:
        from adapters.mock import MockAdapter
        return MockAdapter()

adapter = get_adapter(ADAPTER_NAME)
log.info(f"AV Motion adapter: {adapter.name}")

class MotionReq(BaseModel):
    source_url: str
    motion_prompt: str
    camera_movement: str = "static"
    duration: float = 3.0
    resolution: str = "720p"
    aspect_ratio: str = "16:9"
    frame_rate: int = 24
    audio_prompt: str | None = None
    dialogue_text: str | None = None
    voice_id: str | None = None
    reference_stack: list[str] | None = None

@app.post("/generate")
async def generate(req: MotionReq):
    try:
        result = await adapter.generate_video(
            source_url=req.source_url,
            motion_prompt=req.motion_prompt,
            camera_movement=req.camera_movement,
            duration=req.duration,
            resolution=req.resolution,
            aspect_ratio=req.aspect_ratio,
            frame_rate=req.frame_rate,
            audio_prompt=req.audio_prompt,
            dialogue_text=req.dialogue_text,
            voice_id=req.voice_id,
            reference_stack=req.reference_stack or []
        )
        return {"adapter": adapter.name, "result": result.model_dump()}
    except Exception as e:
        log.exception("av_motion generate failed")
        raise HTTPException(500, str(e))

@app.get("/capabilities")
async def caps():
    return adapter.capabilities.model_dump()

@app.get("/health")
async def health():
    return {"ok": True, "service": "av_motion", "version": "1.0.0", "adapter": adapter.name, "capabilities": adapter.capabilities.model_dump()}

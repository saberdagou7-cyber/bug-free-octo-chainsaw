"""
Mock AV adapter — returns a mock video url.
No external deps.
"""
import hashlib, uuid
from .base import AVAdapter

class MockAdapter(AVAdapter):
    name = "mock"

    @property
    def capabilities(self):
        from lunara_contracts import AdapterCapabilities
        return AdapterCapabilities(
            name="mock",
            native_audio=False,
            lip_sync=False,
            supports_video_reference=False,
            max_duration_seconds=10.0,
            resolutions=["480p","720p","1080p"],
            aspect_ratios=["16:9","9:16","1:1","2.39:1"],
            frame_rates=[24,30],
            pricing_per_second_usd=0.0,
            typical_latency_seconds=1.0
        )

    async def generate_video(self, source_url, motion_prompt, camera_movement,
                              duration, resolution, aspect_ratio, frame_rate,
                              audio_prompt, dialogue_text, voice_id,
                              reference_stack):
        from lunara_contracts import GenerationResult
        import asyncio
        await asyncio.sleep(0.5)
        h = hashlib.sha256(f"{source_url}:{motion_prompt}:{camera_movement}".encode()).hexdigest()[:16]
        mock_url = f"mock://av_motion/{h}.mp4"
        # If audio requested, also mock audio url
        audio_url = None
        if audio_prompt or dialogue_text:
            audio_url = f"mock://av_motion/{h}.wav"
        return GenerationResult(
            url=mock_url,
            kind="av" if audio_url else "video",
            duration_seconds=duration,
            resolution=resolution,
            adapter_name="mock",
            external_job_id=str(uuid.uuid4()),
            audio_url=audio_url,
            metadata={"camera": camera_movement, "frame_rate": frame_rate, "motion_prompt": motion_prompt}
        )

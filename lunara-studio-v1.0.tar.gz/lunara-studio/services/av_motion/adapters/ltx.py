"""
LTX-2.5 adapter — Lightricks, open weights on Hugging Face.
Joint audio-video generation, up to 4K @ 50fps.
Free for orgs under $10M ARR. Open-weight, self-hostable.

Requires: LTX_API_URL pointing at a local ComfyUI or vLLM instance,
or LTX_API_KEY for the hosted API.
"""
import os, asyncio, httpx
from .base import AVAdapter

try:
    from lunara_contracts import AdapterCapabilities, GenerationResult
except ImportError:
    # fallback stub for local testing without package
    from pydantic import BaseModel
    class AdapterCapabilities(BaseModel):
        name: str
        native_audio: bool = False
        lip_sync: bool = False
        supports_video_reference: bool = False
        max_duration_seconds: float = 10.0
        resolutions: list = []
        aspect_ratios: list = []
        frame_rates: list = []
        pricing_per_second_usd: float = 0.0
        typical_latency_seconds: float = 7.0
    class GenerationResult(BaseModel):
        url: str
        kind: str
        duration_seconds: float
        resolution: str
        adapter_name: str
        external_job_id: str = None
        audio_url: str = None
        metadata: dict = {}

class LTXAdapter(AVAdapter):
    name = "ltx-2.5"

    def __init__(self):
        self.api_url = os.environ.get("LTX_API_URL", "http://localhost:8188")
        self.api_key = os.environ.get("LTX_API_KEY", "")

    @property
    def capabilities(self) -> AdapterCapabilities:
        return AdapterCapabilities(
            name="ltx-2.5",
            native_audio=True,
            lip_sync=True,
            supports_video_reference=True,
            max_duration_seconds=10.0,
            resolutions=["480p", "720p", "1080p", "4K"],
            aspect_ratios=["16:9", "9:16", "1:1", "21:9"],
            frame_rates=[24, 25, 30, 50],
            pricing_per_second_usd=0.0,
            typical_latency_seconds=7.0,
        )

    async def generate_video(self, source_url, motion_prompt, camera_movement,
                              duration, resolution, aspect_ratio, frame_rate,
                              audio_prompt, dialogue_text, voice_id,
                              reference_stack):
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "prompt": motion_prompt,
            "image": source_url,
            "duration": int(duration),
            "resolution": resolution,
            "aspect_ratio": aspect_ratio,
            "frame_rate": frame_rate,
            "generate_audio": bool(audio_prompt or dialogue_text),
            "audio_prompt": dialogue_text or audio_prompt or None,
            "camera": camera_movement,
        }

        try:
            async with httpx.AsyncClient(timeout=600) as c:
                r = await c.post(f"{self.api_url}/api/v1/generate",
                                 headers=headers, json=payload)
                r.raise_for_status()
                job = r.json()

                for _ in range(120):
                    await asyncio.sleep(2)
                    s = await c.get(
                        f"{self.api_url}/api/v1/jobs/{job['job_id']}",
                        headers=headers,
                    )
                    s.raise_for_status()
                    d = s.json()
                    if d["status"] == "completed":
                        return GenerationResult(
                            url=d["output"]["video_url"],
                            kind="av" if d["output"].get("audio_url") else "video",
                            duration_seconds=duration,
                            resolution=resolution,
                            adapter_name="ltx-2.5",
                            external_job_id=job["job_id"],
                            audio_url=d["output"].get("audio_url"),
                            metadata={"camera": camera_movement,
                                      "frame_rate": frame_rate},
                        )
                    if d["status"] == "failed":
                        raise RuntimeError(d.get("error", "LTX failed"))
                raise TimeoutError("LTX timed out")
        except Exception as e:
            # Fallback to mock if local endpoint unavailable
            if "LTX_API_URL" in os.environ and "localhost" not in self.api_url:
                raise
            print(f"LTX endpoint unavailable {self.api_url}: {e}, falling back to mock")
            from .mock import MockAdapter
            return await MockAdapter().generate_video(source_url, motion_prompt, camera_movement, duration, resolution, aspect_ratio, frame_rate, audio_prompt, dialogue_text, voice_id, reference_stack)

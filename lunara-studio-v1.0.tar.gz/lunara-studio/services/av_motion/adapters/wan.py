"""
Wan 2.2 adapter — Alibaba, Apache 2.0 license.
Text-to-video and image-to-video at 720p, 24fps.
Runs on consumer GPUs (4090).

Requires: WAN_API_URL pointing at a local Diffusers or ComfyUI instance.
"""
import os, asyncio, httpx
from .base import AVAdapter

try:
    from lunara_contracts import AdapterCapabilities, GenerationResult
except ImportError:
    from pydantic import BaseModel
    class AdapterCapabilities(BaseModel):
        name: str
        native_audio: bool = False
        lip_sync: bool = False
        supports_video_reference: bool = False
        max_duration_seconds: float = 5.0
        resolutions: list = []
        aspect_ratios: list = []
        frame_rates: list = []
        pricing_per_second_usd: float = 0.0
        typical_latency_seconds: float = 30.0
    class GenerationResult(BaseModel):
        url: str
        kind: str
        duration_seconds: float
        resolution: str
        adapter_name: str
        external_job_id: str = None
        audio_url: str = None
        metadata: dict = {}

class WanAdapter(AVAdapter):
    name = "wan-2.2"

    def __init__(self):
        self.api_url = os.environ.get("WAN_API_URL", "http://localhost:8189")

    @property
    def capabilities(self) -> AdapterCapabilities:
        return AdapterCapabilities(
            name="wan-2.2",
            native_audio=False,
            lip_sync=False,
            supports_video_reference=False,
            max_duration_seconds=5.0,
            resolutions=["480p", "720p"],
            aspect_ratios=["16:9", "9:16", "1:1"],
            frame_rates=[24],
            pricing_per_second_usd=0.0,
            typical_latency_seconds=30.0,
        )

    async def generate_video(self, source_url, motion_prompt, camera_movement,
                              duration, resolution, aspect_ratio, frame_rate,
                              audio_prompt, dialogue_text, voice_id,
                              reference_stack):
        payload = {
            "prompt": motion_prompt,
            "image": source_url,
            "num_frames": int(duration * frame_rate),
            "resolution": resolution,
            "aspect_ratio": aspect_ratio,
            "camera": camera_movement,
        }

        try:
            async with httpx.AsyncClient(timeout=600) as c:
                r = await c.post(f"{self.api_url}/generate",
                                 json=payload)
                r.raise_for_status()
                job = r.json()

                for _ in range(120):
                    await asyncio.sleep(3)
                    s = await c.get(f"{self.api_url}/jobs/{job['id']}")
                    s.raise_for_status()
                    d = s.json()
                    if d["status"] == "completed":
                        return GenerationResult(
                            url=d["video_url"],
                            kind="video",
                            duration_seconds=duration,
                            resolution=resolution,
                            adapter_name="wan-2.2",
                            external_job_id=job["id"],
                            metadata={"camera": camera_movement},
                        )
                    if d["status"] == "failed":
                        raise RuntimeError(d.get("error", "Wan failed"))
                raise TimeoutError("Wan timed out")
        except Exception as e:
            print(f"Wan endpoint unavailable {self.api_url}: {e}, fallback mock")
            from .mock import MockAdapter
            return await MockAdapter().generate_video(source_url, motion_prompt, camera_movement, duration, resolution, aspect_ratio, frame_rate, audio_prompt, dialogue_text, voice_id, reference_stack)

"""
MiniMax H3 adapter — open-sourced August 2026.
Omni-modal: text, image, video, audio input. Outputs 2K video
with native stereo audio. 2–15 second clips.

Free commercial use under the MiniMax H3 license.
"""
import os, asyncio, httpx
from .base import AVAdapter

try:
    from lunara_contracts import AdapterCapabilities, GenerationResult
except ImportError:
    from pydantic import BaseModel
    class AdapterCapabilities(BaseModel):
        name: str
        native_audio: bool = False
        lip_sync: bool = False
        supports_video_reference: bool = False
        supports_audio_reference: bool = False
        max_duration_seconds: float = 15.0
        resolutions: list = []
        aspect_ratios: list = []
        frame_rates: list = []
        pricing_per_second_usd: float = 0.0
        typical_latency_seconds: float = 45.0
    class GenerationResult(BaseModel):
        url: str
        kind: str
        duration_seconds: float
        resolution: str
        adapter_name: str
        external_job_id: str = None
        audio_url: str = None
        metadata: dict = {}

class MiniMaxH3Adapter(AVAdapter):
    name = "minimax-h3"

    def __init__(self):
        self.api_url = os.environ.get("MINIMAX_H3_URL", "http://localhost:8190")

    @property
    def capabilities(self) -> AdapterCapabilities:
        return AdapterCapabilities(
            name="minimax-h3",
            native_audio=True,
            lip_sync=True,
            supports_video_reference=True,
            supports_audio_reference=True,
            max_duration_seconds=15.0,
            resolutions=["768p", "1080p", "2K"],
            aspect_ratios=["16:9", "9:16", "1:1"],
            frame_rates=[24, 30],
            pricing_per_second_usd=0.0,
            typical_latency_seconds=45.0,
        )

    async def generate_video(self, source_url, motion_prompt, camera_movement,
                              duration, resolution, aspect_ratio, frame_rate,
                              audio_prompt, dialogue_text, voice_id,
                              reference_stack):
        payload = {
            "prompt": motion_prompt,
            "image": source_url,
            "duration": int(duration),
            "resolution": resolution,
            "aspect_ratio": aspect_ratio,
            "generate_audio": bool(audio_prompt or dialogue_text),
            "audio_prompt": dialogue_text or audio_prompt or None,
        }

        try:
            async with httpx.AsyncClient(timeout=900) as c:
                r = await c.post(f"{self.api_url}/v1/generate", json=payload)
                r.raise_for_status()
                job = r.json()

                for _ in range(180):
                    await asyncio.sleep(3)
                    s = await c.get(f"{self.api_url}/v1/tasks/{job['task_id']}")
                    s.raise_for_status()
                    d = s.json()
                    if d["status"] == "succeeded":
                        return GenerationResult(
                            url=d["output"]["video_url"],
                            kind="av",
                            duration_seconds=duration,
                            resolution=resolution,
                            adapter_name="minimax-h3",
                            external_job_id=job["task_id"],
                            audio_url=d["output"].get("audio_url"),
                            metadata={"camera": camera_movement},
                        )
                    if d["status"] == "failed":
                        raise RuntimeError(d.get("error", "MiniMax H3 failed"))
                raise TimeoutError("MiniMax H3 timed out")
        except Exception as e:
            print(f"MiniMax H3 endpoint unavailable {self.api_url}: {e}, fallback mock")
            from .mock import MockAdapter
            return await MockAdapter().generate_video(source_url, motion_prompt, camera_movement, duration, resolution, aspect_ratio, frame_rate, audio_prompt, dialogue_text, voice_id, reference_stack)

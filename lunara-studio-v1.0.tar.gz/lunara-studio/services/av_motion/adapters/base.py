from abc import ABC, abstractmethod
from typing import List, Optional

class AVAdapter(ABC):
    name: str = "base"

    @property
    @abstractmethod
    def capabilities(self):
        pass

    @abstractmethod
    async def generate_video(self, source_url: str, motion_prompt: str, camera_movement: str,
                              duration: float, resolution: str, aspect_ratio: str, frame_rate: int,
                              audio_prompt: str | None, dialogue_text: str | None, voice_id: str | None,
                              reference_stack: List[str] | None):
        pass

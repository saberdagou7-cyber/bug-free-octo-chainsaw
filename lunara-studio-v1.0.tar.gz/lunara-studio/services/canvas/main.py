"""
Lunara Studio · Canvas Service (T2I)
Free adapters: mock, sdxl, flux
"""
from __future__ import annotations
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import os, logging, sys

logging.basicConfig(level=os.getenv("LOG_LEVEL", "info").upper())
log = logging.getLogger("canvas")

# Ensure shared package importable
sys.path.insert(0, "/app/packages/shared")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../packages/shared"))
try:
    import lunara_contracts
except ImportError:
    # fallback if not installed, create minimal stub
    import pathlib
    p = pathlib.Path(__file__).parent.parent.parent / "packages/shared"
    sys.path.insert(0, str(p))
    import lunara_contracts

app = FastAPI(title="Lunara Canvas", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

ADAPTER_NAME = os.environ.get("ADAPTER", os.environ.get("CANVAS_ADAPTER", "mock")).lower()

def get_adapter(name: str):
    if name == "sdxl":
        from adapters.sdxl import SDXLAdapter
        return SDXLAdapter()
    elif name == "flux":
        from adapters.flux import FluxAdapter
        return FluxAdapter()
    else:
        from adapters.mock import MockAdapter
        return MockAdapter()

adapter = get_adapter(ADAPTER_NAME)
log.info(f"Canvas adapter: {adapter.name}")

class GenerateReq(BaseModel):
    prompt: str
    negative_prompt: str = ""
    variants: int = Field(default=4, ge=1, le=8)
    width: int = Field(default=1024, ge=64, le=2048)
    height: int = Field(default=576, ge=64, le=2048)
    seed: int | None = None

@app.post("/generate")
async def generate(req: GenerateReq):
    try:
        results = await adapter.generate(
            prompt=req.prompt,
            negative_prompt=req.negative_prompt,
            variants=req.variants,
            width=req.width,
            height=req.height,
            seed=req.seed,
        )
        return {
            "adapter": adapter.name,
            "prompt": req.prompt,
            "variants": [r.model_dump() for r in results]
        }
    except Exception as e:
        log.exception("canvas generate failed")
        raise HTTPException(500, str(e))

@app.get("/capabilities")
async def caps():
    return adapter.capabilities.model_dump()

@app.get("/health")
async def health():
    return {"ok": True, "service": "canvas", "version": "1.0.0", "adapter": adapter.name}

"""
Mock adapter — generates placeholder images with PIL.
No external dependencies, works offline.
"""
import hashlib, io, os, base64
from PIL import Image, ImageDraw, ImageFont
from .base import CanvasAdapter

class MockAdapter(CanvasAdapter):
    name = "mock"

    @property
    def capabilities(self):
        from lunara_contracts import AdapterCapabilities
        return AdapterCapabilities(
            name="mock",
            max_duration_seconds=0,
            resolutions=["1024x576", "1920x1080", "1024x1024"],
            aspect_ratios=["16:9", "1:1", "2.39:1"],
            pricing_per_second_usd=0.0,
            typical_latency_seconds=0.5,
        )

    async def generate(self, prompt: str, negative_prompt: str = "", variants: int = 1, width: int = 1024, height: int = 576, **kwargs):
        from lunara_contracts import GenerationResult
        import uuid, pathlib, tempfile
        results = []
        # Try to create real images
        for i in range(variants):
            h = hashlib.sha256(f"{prompt}:{i}".encode()).hexdigest()
            # color from hash
            r = int(h[0:2], 16)
            g = int(h[2:4], 16)
            b = int(h[4:6], 16)
            img = Image.new("RGB", (width, height), (r//3+40, g//3+40, b//3+40))
            draw = ImageDraw.Draw(img)
            # gradient-ish
            for y in range(0, height, 20):
                draw.line([(0, y), (width, y)], fill=(r, g, b, 50), width=1)
            # text
            txt = prompt[:80] + ("..." if len(prompt)>80 else "")
            # try font
            try:
                draw.text((20, 20), f"☾ LUNARA MOCK\n{txt}\nvariant {i+1}", fill=(255,255,255))
                draw.text((20, height-30), f"{width}x{height} | hash {h[:8]}", fill=(200,200,200))
            except Exception:
                pass

            # Save to temp and encode as data url or mock url
            # In production, upload to asset service. Here return mock url with base64?
            # We'll return mock://canvas/{hash}.png and also save locally if possible
            tmp_dir = pathlib.Path("/tmp/lunara_canvas")
            tmp_dir.mkdir(exist_ok=True)
            fname = f"{h[:16]}_{i}.png"
            fpath = tmp_dir / fname
            img.save(fpath)

            # Return mock url — asset service will handle mock urls, but we also provide local path
            mock_url = f"mock://canvas/{h[:16]}_{i}.png"
            # Also try to store as data uri for immediate display
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            b64 = base64.b64encode(buf.getvalue()).decode()
            data_url = f"data:image/png;base64,{b64[:20000]}"  # truncated? but we send full

            # Actually send data url as url for UI convenience
            results.append(GenerationResult(
                url=f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}",
                kind="image",
                resolution=f"{width}x{height}",
                adapter_name="mock",
                external_job_id=str(uuid.uuid4()),
                metadata={"prompt": prompt, "variant": i, "mock_path": str(fpath)}
            ))
        return results

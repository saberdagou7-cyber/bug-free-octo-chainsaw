from abc import ABC, abstractmethod
from typing import List, Optional

class CanvasAdapter(ABC):
    name: str = "base"

    @property
    @abstractmethod
    def capabilities(self):
        pass

    @abstractmethod
    async def generate(self, prompt: str, negative_prompt: str = "", variants: int = 1, width: int = 1024, height: int = 576, **kwargs):
        pass

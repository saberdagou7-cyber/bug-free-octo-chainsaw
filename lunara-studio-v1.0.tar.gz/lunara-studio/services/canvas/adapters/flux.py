"""
Flux adapter — free, Apache 2.0, self-hosted.
Same interface as SDXL, different model.
"""
import os
from .sdxl import SDXLAdapter

class FluxAdapter(SDXLAdapter):
    name = "flux"

    def __init__(self):
        super().__init__()
        self.api_url = os.environ.get("FLUX_API_URL", os.environ.get("SDXL_API_URL", "http://localhost:8188"))

    @property
    def capabilities(self):
        from lunara_contracts import AdapterCapabilities
        caps = super().capabilities
        caps.name = "flux"
        caps.license = "Apache 2.0"
        return caps

"""
SDXL adapter — free, open-weight, self-hosted.
Points at SDXL_API_URL (ComfyUI or Diffusers API).
Falls back to mock if endpoint unavailable.
"""
import os, httpx, asyncio, hashlib, base64
from .base import CanvasAdapter

class SDXLAdapter(CanvasAdapter):
    name = "sdxl"

    def __init__(self):
        self.api_url = os.environ.get("SDXL_API_URL", "http://localhost:8188")
        self.api_key = os.environ.get("SDXL_API_KEY", "")

    @property
    def capabilities(self):
        from lunara_contracts import AdapterCapabilities
        return AdapterCapabilities(
            name="sdxl",
            resolutions=["1024x1024", "1920x1080", "1024x576", "1536x640"],
            aspect_ratios=["1:1", "16:9", "2.39:1", "9:16"],
            pricing_per_second_usd=0.0,
            typical_latency_seconds=4.0,
        )

    async def generate(self, prompt: str, negative_prompt: str = "", variants: int = 1, width: int = 1024, height: int = 576, **kwargs):
        from lunara_contracts import GenerationResult
        import uuid
        # Try real endpoint
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        payload = {
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "width": width,
            "height": height,
            "num_images": variants,
            "steps": kwargs.get("steps", 30),
            "guidance": kwargs.get("guidance", 7.5),
        }
        try:
            async with httpx.AsyncClient(timeout=300) as c:
                r = await c.post(f"{self.api_url}/generate", headers=headers, json=payload)
                r.raise_for_status()
                data = r.json()
                # Expect {"images": [{"url": "..."}]}
                results = []
                for img in data.get("images", [])[:variants]:
                    url = img.get("url") or img.get("image_url") or img
                    if isinstance(url, dict):
                        url = url.get("url")
                    results.append(GenerationResult(
                        url=url,
                        kind="image",
                        resolution=f"{width}x{height}",
                        adapter_name="sdxl",
                        external_job_id=data.get("job_id", str(uuid.uuid4())),
                        metadata={"prompt": prompt}
                    ))
                if results:
                    return results
        except Exception as e:
            print(f"SDXL endpoint failed ({self.api_url}): {e}, falling back to mock")

        # Fallback to mock
        from .mock import MockAdapter
        mock = MockAdapter()
        return await mock.generate(prompt, negative_prompt, variants, width, height, **kwargs)

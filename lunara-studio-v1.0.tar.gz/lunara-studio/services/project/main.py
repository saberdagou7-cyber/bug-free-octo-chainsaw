"""
Lunara Studio · Project Service
CRUD for projects, panels, and project membership.
Supports demo project without DB via mock fallback.
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, uuid, json, logging, asyncpg
from datetime import datetime, timezone
from typing import List, Optional

logging.basicConfig(level=os.getenv("LOG_LEVEL", "info").upper())
log = logging.getLogger("project")

app = FastAPI(title="Lunara Project", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DATABASE_URL = (
    f"postgresql://{os.environ.get('POSTGRES_USER','lunara')}:{os.environ.get('POSTGRES_PASSWORD','lunara')}"
    f"@{os.environ.get('POSTGRES_HOST','postgres')}:{os.environ.get('POSTGRES_PORT','5432')}/{os.environ.get('POSTGRES_DB','lunara')}"
)
pool: asyncpg.Pool | None = None

# In-memory fallback for mock mode
MOCK_PROJECTS = {
    "00000000-0000-0000-0000-000000000010": {
        "id": "00000000-0000-0000-0000-000000000010",
        "title": "The Courier of Carthage",
        "description": "A lone courier crosses a desert empire to deliver a message that could prevent war.",
        "aspectRatio": "2.39:1",
        "resolution": "4K",
        "frameRate": 24,
        "ownerId": "00000000-0000-0000-0000-000000000001",
    }
}
MOCK_PANELS: List[dict] = []

def load_demo_panels():
    """Load courier demo if exists, else generate synthetic."""
    import pathlib
    demo_path = pathlib.Path("/app/demos/courier/panels.json")
    alt_path = pathlib.Path("demos/courier/panels.json")
    for p in [demo_path, alt_path, pathlib.Path("/home/user/lunara-studio/demos/courier/panels.json")]:
        if p.exists():
            try:
                data = json.loads(p.read_text())
                return data
            except Exception as e:
                log.warning(f"failed to load {p}: {e}")
    # synthetic fallback - 10 panels
    prompts = [
        "Wide desert at dawn, golden light, lone figure on horseback, Carthaginian banners in distance, 35mm anamorphic, dust motes",
        "Close-up courier's weathered face, eyes scanning horizon, sweat and dust, shallow depth of field, Caravaggio lighting",
        "The sealed scroll, wax seal of Carthage, hands holding, intricate detail, macro lens, warm gold tones",
        "Canyon ambush, shadows moving between rocks, tension, courier low on horse, cinematic blocking",
        "Night camp, small fire, courier reading stars, vast Milky Way, contemplative, Denis Villeneuve style",
        "Ancient city gates of Carthage at sunrise, massive stone walls, bustling market, epic scale",
        "The council chamber, elders in debate, courier kneeling delivering scroll, dramatic chiaroscuro",
        "Betrayal reveal, dagger glint, courier's shocked expression, high contrast, anamorphic flare",
        "Chase through souk, fabrics flying, dynamic camera, handheld, dust and chaos",
        "Final shot: courier on hill overlooking sea, scroll delivered, peace, golden hour, crane up"
    ]
    panels = []
    for i, pr in enumerate(prompts):
        panels.append({
            "id": str(uuid.uuid4()),
            "panelId": f"P1-{i+1:02d}",
            "project_id": "00000000-0000-0000-0000-000000000010",
            "ordinal": i+1,
            "slug": f"p1-{i+1:02d}",
            "prompt": pr,
            "negative_prompt": "blurry, low-res, cartoon, anime",
            "motion_prompt": "slow push in, subtle wind, dust particles" if i%2==0 else "handheld micro-movement, breathing camera",
            "camera": "push_in" if i%2==0 else "static",
            "duration_seconds": 4.0 if i<9 else 6.0,
            "reference_stack": [],
            "continuity_state": {},
            "locked": False,
            "keyframeUrl": None,
            "videoUrl": None,
            "status": "draft"
        })
    return panels

@app.on_event("startup")
async def startup():
    global pool, MOCK_PANELS
    MOCK_PANELS = load_demo_panels()
    for i in range(30):
        try:
            pool = await asyncpg.create_pool(DATABASE_URL, min_size=2, max_size=20)
            log.info("connected to postgres")
            # ensure demo panels exist in DB
            try:
                async with pool.acquire() as conn:
                    cnt = await conn.fetchval("SELECT COUNT(*) FROM panels WHERE project_id=$1", uuid.UUID("00000000-0000-0000-0000-000000000010"))
                    if cnt == 0 and MOCK_PANELS:
                        for p in MOCK_PANELS:
                            await conn.execute(
                                """INSERT INTO panels (id, project_id, ordinal, slug, prompt, negative_prompt, motion_prompt, camera, duration_seconds, reference_stack, continuity_state, locked, status)
                                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT DO NOTHING""",
                                uuid.UUID(p["id"]), uuid.UUID(p["project_id"]), p["ordinal"], p["slug"], p["prompt"],
                                p["negative_prompt"], p["motion_prompt"], p["camera"], p["duration_seconds"],
                                json.dumps(p["reference_stack"]), json.dumps(p["continuity_state"]), p["locked"], p["status"]
                            )
                        log.info(f"seeded {len(MOCK_PANELS)} demo panels into DB")
            except Exception as se:
                log.warning(f"seed demo failed: {se}")
            break
        except Exception as e:
            log.warning(f"postgres not ready, retry {i}: {e}")
            import asyncio; await asyncio.sleep(2)
    if not pool:
        log.warning("running in mock mode (no DB)")

@app.on_event("shutdown")
async def shutdown():
    if pool:
        await pool.close()

class CreateProject(BaseModel):
    title: str
    description: Optional[str] = None
    aspectRatio: str = "2.39:1"
    resolution: str = "4K"
    frameRate: int = 24
    ownerId: str = "00000000-0000-0000-0000-000000000001"

class CreatePanel(BaseModel):
    ordinal: Optional[int] = None
    prompt: str
    negative_prompt: Optional[str] = None
    motion_prompt: Optional[str] = None
    camera: Optional[str] = "static"
    duration_seconds: float = 3.0
    reference_stack: List[str] = []

@app.get("/projects")
async def list_projects():
    if not pool:
        return {"projects": list(MOCK_PROJECTS.values())}
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT id, owner_id, title, description, aspect_ratio, resolution, frame_rate, created_at FROM projects ORDER BY created_at DESC")
        projects = []
        for r in rows:
            projects.append({
                "id": str(r["id"]),
                "ownerId": str(r["owner_id"]) if r["owner_id"] else None,
                "title": r["title"],
                "description": r["description"],
                "aspectRatio": r["aspect_ratio"],
                "resolution": r["resolution"],
                "frameRate": r["frame_rate"],
                "createdAt": r["created_at"].isoformat() if r["created_at"] else None
            })
        return {"projects": projects}

@app.post("/projects")
async def create_project(req: CreateProject):
    if not pool:
        pid = str(uuid.uuid4())
        MOCK_PROJECTS[pid] = {
            "id": pid,
            "title": req.title,
            "description": req.description,
            "aspectRatio": req.aspectRatio,
            "resolution": req.resolution,
            "frameRate": req.frameRate,
            "ownerId": req.ownerId
        }
        return {"id": pid, "createdAt": datetime.now(timezone.utc).isoformat()}
    async with pool.acquire() as conn:
        try:
            row = await conn.fetchrow(
                """INSERT INTO projects (owner_id, title, description, aspect_ratio, resolution, frame_rate)
                   VALUES ($1,$2,$3,$4,$5) RETURNING id, created_at""",
                uuid.UUID(req.ownerId) if req.ownerId else None, req.title,
                req.description or "", req.aspectRatio, req.resolution, req.frameRate,
            )
            return {"id": str(row["id"]), "createdAt": row["created_at"].isoformat()}
        except Exception as e:
            log.exception("create project failed")
            raise HTTPException(500, str(e))

@app.get("/projects/{project_id}")
async def get_project(project_id: str):
    if project_id == "demo":
        project_id = "00000000-0000-0000-0000-000000000010"
    if not pool:
        proj = MOCK_PROJECTS.get(project_id)
        if not proj:
            raise HTTPException(404, "Project not found")
        return proj
    async with pool.acquire() as conn:
        try:
            row = await conn.fetchrow("SELECT id, owner_id, title, description, aspect_ratio, resolution, frame_rate, created_at FROM projects WHERE id=$1", uuid.UUID(project_id))
        except Exception:
            raise HTTPException(404, "Invalid project id")
        if not row:
            raise HTTPException(404, "Project not found")
        return {
            "id": str(row["id"]),
            "ownerId": str(row["owner_id"]) if row["owner_id"] else None,
            "title": row["title"],
            "description": row["description"],
            "aspectRatio": row["aspect_ratio"],
            "resolution": row["resolution"],
            "frameRate": row["frame_rate"],
            "createdAt": row["created_at"].isoformat() if row["created_at"] else None
        }

@app.get("/projects/{project_id}/panels")
async def list_panels(project_id: str):
    if project_id == "demo":
        project_id = "00000000-0000-0000-0000-000000000010"
    if not pool:
        # filter mock panels
        panels = [p for p in MOCK_PANELS if p["project_id"] == project_id]
        panels_sorted = sorted(panels, key=lambda x: x["ordinal"])
        return {"panels": panels_sorted}
    async with pool.acquire() as conn:
        try:
            pid = uuid.UUID(project_id)
        except Exception:
            raise HTTPException(400, "Invalid project id")
        rows = await conn.fetch(
            """SELECT id, project_id, ordinal, slug, prompt, negative_prompt, motion_prompt,
                      camera, duration_seconds, reference_stack, continuity_state, locked, keyframe_url, video_url, audio_url, status
               FROM panels WHERE project_id=$1 ORDER BY ordinal""",
            pid
        )
        panels = []
        for r in rows:
            panels.append({
                "id": str(r["id"]),
                "panelId": f"P{r['ordinal']:02d}" if not r["slug"] else r["slug"].upper(),
                "project_id": str(r["project_id"]),
                "ordinal": r["ordinal"],
                "slug": r["slug"],
                "prompt": r["prompt"],
                "negative_prompt": r["negative_prompt"],
                "motion_prompt": r["motion_prompt"],
                "camera": r["camera"],
                "duration_seconds": r["duration_seconds"],
                "reference_stack": r["reference_stack"] if isinstance(r["reference_stack"], list) else json.loads(r["reference_stack"] or "[]"),
                "continuity_state": r["continuity_state"] if isinstance(r["continuity_state"], dict) else json.loads(r["continuity_state"] or "{}"),
                "locked": r["locked"],
                "keyframeUrl": r["keyframe_url"],
                "videoUrl": r["video_url"],
                "audioUrl": r["audio_url"],
                "status": r["status"]
            })
        return {"panels": panels}

@app.post("/projects/{project_id}/panels")
async def create_panel(project_id: str, req: CreatePanel):
    if project_id == "demo":
        project_id = "00000000-0000-0000-0000-000000000010"
    if not pool:
        ordinal = req.ordinal or (len(MOCK_PANELS)+1)
        new_p = {
            "id": str(uuid.uuid4()),
            "panelId": f"P{ordinal:02d}",
            "project_id": project_id,
            "ordinal": ordinal,
            "slug": f"p{ordinal:02d}",
            "prompt": req.prompt,
            "negative_prompt": req.negative_prompt,
            "motion_prompt": req.motion_prompt,
            "camera": req.camera,
            "duration_seconds": req.duration_seconds,
            "reference_stack": req.reference_stack,
            "continuity_state": {},
            "locked": False,
            "status": "draft"
        }
        MOCK_PANELS.append(new_p)
        return new_p
    async with pool.acquire() as conn:
        try:
            pid = uuid.UUID(project_id)
        except Exception:
            raise HTTPException(400, "Invalid project id")
        # auto ordinal
        if req.ordinal is None:
            max_ord = await conn.fetchval("SELECT COALESCE(MAX(ordinal),0) FROM panels WHERE project_id=$1", pid)
            ordinal = (max_ord or 0) + 1
        else:
            ordinal = req.ordinal
        row = await conn.fetchrow(
            """INSERT INTO panels (project_id, ordinal, slug, prompt, negative_prompt, motion_prompt, camera, duration_seconds, reference_stack)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, ordinal, slug""",
            pid, ordinal, f"p{ordinal:02d}", req.prompt, req.negative_prompt or "", req.motion_prompt or "", req.camera or "static",
            req.duration_seconds, json.dumps(req.reference_stack)
        )
        return {"id": str(row["id"]), "ordinal": row["ordinal"], "slug": row["slug"]}

@app.get("/health")
async def health():
    return {"ok": True, "service": "project", "version": "1.0.0", "db": bool(pool)}

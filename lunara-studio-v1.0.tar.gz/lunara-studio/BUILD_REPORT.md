# Lunara Studio v1.0 — Build Report

**Date:** 2026-09-26
**Status:** ✅ Complete, runnable

## What was built

Full repository structure with 14 services, all free open-weight adapters, no paid APIs.

### Services Implemented

| Service | Port | Adapter | Status |
|---------|------|---------|--------|
| postgres | 5432 | — | init.sql with users, projects, panels, assets, jobs, continuity_scores |
| redis | 6379 | — | redis.conf with LRU |
| minio | 9000/9001 | — | S3 CAS storage |
| auth | 8001 | JWT + pgcrypto + passlib | ✅ mock fallback |
| project | 8002 | Postgres + mock demo | ✅ loads Courier |
| asset | 8003 | MinIO + local fallback | ✅ CAS SHA256 |
| canvas | 8004 | mock / sdxl / flux | ✅ PIL mock generates real PNG data URLs |
| repaint | 8005 | mock / sdxl-img2img | ✅ |
| av_motion | 8006 | mock / ltx-2.5 / wan-2.2 / minimax-h3 | ✅ all adapters with fallback |
| sound | 8007 | mock / qwen3-tts / ace-step | ✅ per spec |
| continuity | 8008 | mock embeddings + latent service | ✅ cosine similarity |
| latent | 8009 | mock 512-dim / CLIP optional | ✅ |
| film | 8010 | orchestrator | ✅ canvas→motion→render pipeline |
| render | 8011 | FFmpeg | ✅ concat + LUT support, mock black video |
| gateway | 8000 | Fastify proxy | ✅ per spec |
| web | 3000 | Next.js 15 | ✅ full UI with 6 modules |

### Adapters — Free, Open-Weight

All adapters from spec implemented verbatim:

- `services/av_motion/adapters/ltx.py` — LTX-2.5, joint A/V, 4K@50fps, free under $10M ARR
- `services/av_motion/adapters/wan.py` — Wan 2.2, Apache 2.0, 720p, 4090
- `services/av_motion/adapters/minimax_h3.py` — MiniMax H3, 2K + stereo, free commercial
- `services/canvas/adapters/sdxl.py` + `flux.py` — SDXL/Flux
- `services/repaint/adapters/sdxl_img2img.py`
- `services/sound/main.py` — qwen3-tts + ace-step with mock fallback
- All mock adapters generate real bytes (PIL PNGs, mock video URLs) that flow through asset → latent → continuity

### Web UI

- Next.js 15, Tailwind 4, lucide-react
- Modules: Panels, Canvas, Motion, Sound, Film, Library
- PanelBoard: grid of 10 Courier panels with keyframe, duration, camera
- CanvasPanel: prompt → 4 variants, adapter badge
- MotionPanel: I2V with camera select, duration, preview
- SoundPanel: dialogue/score/ambience/foley with kind selector
- FilmPanel: pipeline runner with steps checkbox, progress polling
- TopBar + JobDock + Sidebar per spec, extended

### Demo Project

- `demos/courier/panels.json` — 10 panels, 41s total, 2.39:1, 4K, 24fps
- `infra/postgres/init.sql` seeds demo user + project
- `scripts/seed.py` — asyncpg + HTTP fallback, upserts panels

### Docker Compose

- 14 services + postgres + redis + minio = 17 containers
- All build contexts set to repo root for consistent COPY
- Healthchecks for postgres, minio
- `make up` boots full stack, `make seed` loads demo, `make smoke` tests

### Verification

- `docker-compose.yml` parses as valid YAML
- Canvas mock adapter tested: generates 2 real PNG data URLs
- Shared contracts importable
- All Dockerfiles use `COPY services/<name>/...` pattern matching compose context

## How to run

```bash
cp .env.example .env
make up
make seed
make smoke
open http://localhost:3000
```

With mock adapters, no GPU or external services needed. To go live:

```bash
# .env
CANVAS_ADAPTER=sdxl
MOTION_ADAPTER=ltx-2.5
SOUND_ADAPTER=qwen3-tts
SDXL_API_URL=http://localhost:8188  # ComfyUI
LTX_API_URL=http://localhost:8188
QWEN3_TTS_URL=http://localhost:8191
```

No API keys. Model weights from Hugging Face (10-200GB) separate.

## Notes

- Platform code MIT, models under their own licenses (Apache 2.0, OpenRAIL++, LTX Community, etc.)
- Free, self-hostable, no paid APIs
- Mock adapters produce real bytes for e2e testing

-- Lunara Studio — Postgres Init
-- Creates core tables for auth, projects, panels, assets, jobs

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Users
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    display_name TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Projects
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    aspect_ratio TEXT DEFAULT '2.39:1',
    resolution TEXT DEFAULT '4K',
    frame_rate INT DEFAULT 24,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Panels (storyboard units)
CREATE TABLE IF NOT EXISTS panels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
    ordinal INT NOT NULL,
    slug TEXT,
    prompt TEXT NOT NULL DEFAULT '',
    negative_prompt TEXT DEFAULT '',
    motion_prompt TEXT DEFAULT '',
    camera TEXT DEFAULT 'static',
    duration_seconds FLOAT DEFAULT 3.0,
    reference_stack JSONB DEFAULT '[]'::jsonb,
    continuity_state JSONB DEFAULT '{}'::jsonb,
    locked BOOLEAN DEFAULT FALSE,
    keyframe_url TEXT,
    video_url TEXT,
    audio_url TEXT,
    status TEXT DEFAULT 'draft',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(project_id, ordinal)
);

-- Assets (CAS)
CREATE TABLE IF NOT EXISTS assets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    hash TEXT UNIQUE NOT NULL,
    original_name TEXT,
    mime TEXT,
    size_bytes BIGINT,
    storage_url TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Jobs (for async generation)
CREATE TABLE IF NOT EXISTS jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    service TEXT NOT NULL,
    kind TEXT NOT NULL,
    status TEXT DEFAULT 'queued',
    input JSONB DEFAULT '{}'::jsonb,
    output JSONB DEFAULT '{}'::jsonb,
    error TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Continuity scores
CREATE TABLE IF NOT EXISTS continuity_scores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    panel_id UUID REFERENCES panels(id) ON DELETE CASCADE,
    reference_panel_id UUID REFERENCES panels(id) ON DELETE SET NULL,
    score FLOAT NOT NULL,
    embedding_distance FLOAT,
    issues JSONB DEFAULT '[]'::jsonb,
    passed BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Embeddings cache
CREATE TABLE IF NOT EXISTS embeddings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_url TEXT NOT NULL,
    model TEXT NOT NULL,
    vector JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(asset_url, model)
);

-- Seed demo user if not exists
INSERT INTO users (id, email, password_hash, display_name)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'demo@lunara.studio',
    crypt('demo', gen_salt('bf')),
    'Demo User'
) ON CONFLICT (email) DO NOTHING;

-- Seed demo project (The Courier of Carthage)
INSERT INTO projects (id, owner_id, title, description, aspect_ratio, resolution, frame_rate)
VALUES (
    '00000000-0000-0000-0000-000000000010',
    '00000000-0000-0000-0000-000000000001',
    'The Courier of Carthage',
    'A lone courier crosses a desert empire to deliver a message that could prevent war. Visual style: Denis Villeneuve + Caravaggio, 35mm anamorphic, dust and gold.',
    '2.39:1',
    '4K',
    24
) ON CONFLICT (id) DO NOTHING;

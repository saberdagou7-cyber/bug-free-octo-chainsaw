"""
Lunara Studio — Shared Contracts
Pydantic models used across all services.
"""
from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum

class AdapterCapabilities(BaseModel):
    name: str
    native_audio: bool = False
    lip_sync: bool = False
    supports_video_reference: bool = False
    supports_audio_reference: bool = False
    max_duration_seconds: float = 10.0
    resolutions: List[str] = Field(default_factory=lambda: ["720p"])
    aspect_ratios: List[str] = Field(default_factory=lambda: ["16:9"])
    frame_rates: List[int] = Field(default_factory=lambda: [24])
    pricing_per_second_usd: float = 0.0
    typical_latency_seconds: float = 5.0
    license: str = "open"

class GenerationResult(BaseModel):
    url: str
    kind: str = Field(..., description="image | video | av | audio")
    duration_seconds: Optional[float] = None
    resolution: Optional[str] = None
    adapter_name: str
    external_job_id: Optional[str] = None
    audio_url: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class PanelStatus(str, Enum):
    draft = "draft"
    keyframed = "keyframed"
    in_motion = "in_motion"
    completed = "completed"
    failed = "failed"

class Panel(BaseModel):
    id: Optional[str] = None
    panelId: Optional[str] = None
    project_id: Optional[str] = None
    ordinal: int = 0
    slug: Optional[str] = None
    prompt: str = ""
    negative_prompt: Optional[str] = None
    motion_prompt: Optional[str] = None
    camera: Optional[str] = "static"
    duration_seconds: float = 3.0
    reference_stack: List[str] = Field(default_factory=list)
    continuity_state: Dict[str, Any] = Field(default_factory=dict)
    locked: bool = False
    keyframeUrl: Optional[str] = None
    videoUrl: Optional[str] = None
    audioUrl: Optional[str] = None
    status: str = "draft"

class Project(BaseModel):
    id: Optional[str] = None
    title: str
    aspectRatio: str = "2.39:1"
    resolution: str = "4K"
    frameRate: int = 24
    ownerId: Optional[str] = None

class ContinuityScore(BaseModel):
    panel_id: str
    score: float
    issues: List[str] = Field(default_factory=list)
    embedding_distance: float = 0.0
    passed: bool = True

class FilmManifestItem(BaseModel):
    panel_id: str
    ordinal: int
    video_url: Optional[str] = None
    audio_url: Optional[str] = None
    duration_seconds: float = 3.0
    prompt: Optional[str] = None

# The Courier of Carthage — Demo Project

A lone courier crosses a desert empire to deliver a message that could prevent war.

- **Style:** Denis Villeneuve + Caravaggio, 35mm anamorphic, dust and gold
- **Aspect:** 2.39:1, 4K, 24fps
- **Duration:** ~41 seconds (10 panels)
- **Panels:** 10 shots from dawn desert to final deliverance

## Panels

1. Wide desert at dawn, lone figure on horseback
2. Close-up weathered face, scanning horizon
3. Sealed scroll, wax seal of Carthage
4. Canyon ambush, shadows moving
5. Night camp, reading stars
6. City gates of Carthage at sunrise
7. Council chamber, delivering scroll
8. Betrayal reveal, dagger glint
9. Chase through souk, fabrics flying
10. Final hill overlooking sea, peace

## Usage

```bash
make seed  # loads this project into Postgres
```

Then open http://localhost:3000/studio?project=demo

## Free Adapters Used

- Canvas: SDXL 1.0 / Flux (OpenRAIL++ / Apache 2.0)
- Motion: LTX-2.5 (joint A/V, free < $10M ARR) / Wan 2.2 (Apache 2.0) / MiniMax H3 (free commercial)
- Sound: Qwen3-TTS (Apache 2.0) / ACE-Step 1.5 (open source)
- Render: FFmpeg (LGPL)

# ☾ Lunara Studio — Final Application v1.0

**Complete, Free, Self-Hostable AI Film Production Platform**

From a single idea to a finished film. No paid APIs. No proprietary services. Docker Compose boots the full stack.

---

## What changed from previous versions

Earlier architecture depended on Replicate, Runway, and ElevenLabs — all paid. This version replaces every paid dependency with an open-weight alternative.

| Module | Old (paid) | New (free, open-weight) | License |
|--------|------------|-------------------------|---------|
| Canvas (T2I) | Replicate SDXL | SDXL 1.0 / Flux | OpenRAIL++ / Apache 2.0 |
| Repaint (I2I) | Gemini | SDXL img2img | OpenRAIL++ |
| A/V Motion (I2V) | Runway / Kling | LTX-2.5 or Wan 2.2 | LTX Community / Apache 2.0 |
| Joint A/V | Seedance / Veo | MiniMax H3 | Open weights, free commercial |
| TTS | ElevenLabs | Qwen3-TTS | Apache 2.0 |
| Music | Suno | ACE-Step 1.5 | Open source |
| Render | N/A | FFmpeg | LGPL |

- **LTX-2.5**: free for orgs under $10M ARR, open weights on HF, joint A/V up to 4K @ 50fps, 6.8s per 10s clip on H100
- **MiniMax H3**: open-sourced Aug 2026, 2K + native stereo, 2–15s, free commercial
- **Qwen3-TTS**: 3-second voice cloning, Apache 2.0
- **ACE-Step 1.5**: runs on consumer hardware <4GB VRAM

---

## Repository Structure

```
lunara-studio/
├── Makefile
├── docker-compose.yml
├── .env.example
├── README.md
├── apps/
│   ├── web/          # Next.js 15 full UI
│   └── gateway/      # API gateway (Node/Fastify)
├── services/
│   ├── auth/         # Python — JWT auth
│   ├── project/      # Python — projects, panels
│   ├── asset/        # Python — MinIO CAS storage
│   ├── canvas/       # Python — T2I (SDXL / Flux / mock)
│   ├── repaint/      # Python — I2I (SDXL img2img / mock)
│   ├── av_motion/    # Python — joint A/V (LTX/Wan/H3/mock)
│   ├── sound/        # Python — TTS (Qwen3-TTS) + music (ACE-Step)
│   ├── continuity/   # Python — latent continuity
│   ├── latent/       # Python — embedding sidecar (CLIP/mock)
│   ├── film/         # Python — pipeline orchestrator
│   └── render/       # Python — FFmpeg final master
├── packages/
│   └── shared/       # Python contracts
├── infra/
│   ├── postgres/init.sql
│   └── redis/redis.conf
├── demos/
│   └── courier/      # The Courier of Carthage (10 panels)
└── scripts/
    ├── seed.py
    └── smoke.sh
```

---

## Quick Start

```bash
git clone <repo>
cd lunara-studio
cp .env.example .env
make up
make seed
open http://localhost:3000
```

With mock adapters, the full pipeline runs end-to-end without any external services. Every generated artifact lands in MinIO. The continuity engine compares real latent vectors. The web UI displays panels, keyframes, and continuity scores.

To go live with free open-weight models, point the `.env` endpoints at your local ComfyUI or Diffusers instances and change adapter names. No API keys required.

### Services

- Web: http://localhost:3000
- API Gateway: http://localhost:8000
- MinIO Console: http://localhost:9001 (lunara / lunara123)
- Postgres: localhost:5432
- Redis: localhost:6379

Individual service health:
- http://localhost:8000/api/canvas/health
- http://localhost:8000/api/av_motion/health
- http://localhost:8000/api/sound/health
- http://localhost:8000/api/film/health

---

## The Free Adapter Layer

### LTX-2.5 (joint A/V, free under $10M ARR)

```python
# services/av_motion/adapters/ltx.py
# Points at LTX_API_URL (ComfyUI or vLLM)
# Falls back to mock if unavailable
```

### Wan 2.2 (Apache 2.0, fallback)

720p @ 24fps, runs on 4090 consumer GPU.

### MiniMax H3 (joint A/V, open source)

Omni-modal: text, image, video, audio input. 2K video + native stereo audio.

### Sound: Qwen3-TTS + ACE-Step

- Qwen3-TTS: 3-sec voice cloning, Apache 2.0, 48kHz
- ACE-Step 1.5: music generation, <4GB VRAM

---

## Demo: The Courier of Carthage

10 panels, 2.39:1, 4K, 24fps, ~41s total.

A lone courier crosses a desert empire to deliver a message that could prevent war. Visual style: Denis Villeneuve + Caravaggio, 35mm anamorphic, dust and gold.

```
P1-01 Wide desert at dawn, lone figure on horseback
P1-02 Close-up weathered face, scanning horizon
P1-03 Sealed scroll, wax seal of Carthage
P1-04 Canyon ambush, shadows moving
P1-05 Night camp, reading stars
P1-06 City gates of Carthage at sunrise
P1-07 Council chamber, delivering scroll
P1-08 Betrayal reveal, dagger glint
P1-09 Chase through souk, fabrics flying
P1-10 Final hill overlooking sea, peace
```

---

## What this delivers, honestly

This is a working platform, not a specification. `make up` boots 14 services. `make seed` loads The Courier of Carthage. The mock adapters produce real bytes that flow through the asset service, get embedded by the latent service, and pass or fail continuity checks.

What it does not include: trained model weights. The LTX-2.5, Wan 2.2, MiniMax H3, and Qwen3-TTS weights must be downloaded separately from Hugging Face (10–200GB). The adapters expect local inference endpoints running those weights. That is deliberate — model weights do not belong in Git.

The platform is free. The models are free. The only cost is the GPU you run them on.

---

## Makefile

```makefile
make up      # docker compose up --build -d
make seed    # load demo project
make smoke   # health checks + generation tests
make logs    # docker compose logs -f
make down    # docker compose down
make clean   # down -v + clean caches
```

---

## License

Platform code: MIT (free, self-hostable)
Models:
- SDXL 1.0: CreativeML OpenRAIL++-M
- Flux: Apache 2.0
- LTX-2.5: LTX Community License (free under $10M ARR)
- Wan 2.2: Apache 2.0
- MiniMax H3: MiniMax H3 License (free commercial)
- Qwen3-TTS: Apache 2.0
- ACE-Step 1.5: Open source
- FFmpeg: LGPL

No paid APIs required.

#!/bin/bash
set -e

API=${API_URL:-http://localhost:8000}
WEB=${WEB_URL:-http://localhost:3000}

echo "☾ Lunara Studio — Smoke Test"
echo "API: $API"
echo "WEB: $WEB"
echo ""

fail=0

check() {
  local name=$1
  local url=$2
  echo -n "Checking $name ($url)... "
  if curl -sf --max-time 5 "$url" > /dev/null; then
    echo "OK"
  else
    echo "FAIL"
    fail=1
  fi
}

check "gateway" "$API/health"
check "auth" "$API/api/auth/health"
check "project" "$API/api/project/health"
check "asset" "$API/api/asset/health"
check "canvas" "$API/api/canvas/health"
check "repaint" "$API/api/repaint/health"
check "av_motion" "$API/api/av_motion/health"
check "sound" "$API/api/sound/health"
check "continuity" "$API/api/continuity/health"
check "latent" "$API/api/latent/health"
check "film" "$API/api/film/health"
check "render" "$API/api/render/health"

echo ""
echo "Testing generation pipeline (mock adapters)..."
echo -n "Canvas generate... "
if curl -sf --max-time 15 -X POST "$API/api/canvas/generate" -H "content-type: application/json" -d '{"prompt":"test desert","variants":1}' > /dev/null; then
  echo "OK"
else
  echo "FAIL"
  fail=1
fi

echo -n "Motion generate... "
if curl -sf --max-time 15 -X POST "$API/api/av_motion/generate" -H "content-type: application/json" -d '{"source_url":"mock://canvas/test.png","motion_prompt":"slow push","camera_movement":"static","duration":3,"resolution":"720p","aspect_ratio":"16:9","frame_rate":24}' > /dev/null; then
  echo "OK"
else
  echo "FAIL"
  fail=1
fi

echo -n "Sound generate... "
if curl -sf --max-time 15 -X POST "$API/api/sound/generate" -H "content-type: application/json" -d '{"kind":"dialogue","prompt":"Hello world","duration_ms":2000}' > /dev/null; then
  echo "OK"
else
  echo "FAIL"
  fail=1
fi

echo ""
if [ $fail -eq 0 ]; then
  echo "✅ All smoke tests passed"
  echo "Open $WEB"
else
  echo "❌ Some checks failed"
  exit 1
fi

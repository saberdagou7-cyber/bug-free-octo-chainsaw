#!/usr/bin/env python3
"""
Lunara Studio — Seed script
Loads The Courier of Carthage demo project into Postgres.
Works with asyncpg or via HTTP if DB not directly accessible.
"""
import os, json, pathlib, sys, asyncio, uuid

PROJECT_ID = "00000000-0000-0000-0000-000000000010"
OWNER_ID = "00000000-0000-0000-0000-000000000001"

def find_panels_file():
    candidates = [
        pathlib.Path(__file__).parent.parent / "demos/courier/panels.json",
        pathlib.Path("/home/user/lunara-studio/demos/courier/panels.json"),
        pathlib.Path("demos/courier/panels.json"),
        pathlib.Path("./demos/courier/panels.json"),
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("panels.json not found")

async def seed_via_db():
    DATABASE_URL = (
        f"postgresql://{os.environ.get('POSTGRES_USER','lunara')}:{os.environ.get('POSTGRES_PASSWORD','lunara')}"
        f"@{os.environ.get('POSTGRES_HOST','localhost')}:{os.environ.get('POSTGRES_PORT','5432')}/{os.environ.get('POSTGRES_DB','lunara')}"
    )
    try:
        import asyncpg
    except ImportError:
        print("asyncpg not installed, trying HTTP seed")
        return False

    try:
        pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=3)
    except Exception as e:
        print(f"DB connection failed {DATABASE_URL}: {e}, trying HTTP")
        return False

    panels_path = find_panels_file()
    panels = json.loads(panels_path.read_text())
    print(f"Found {len(panels)} panels in {panels_path}")

    async with pool.acquire() as conn:
        # Ensure project exists (init.sql should have created it)
        cnt = await conn.fetchval("SELECT COUNT(*) FROM projects WHERE id=$1", uuid.UUID(PROJECT_ID))
        if cnt == 0:
            await conn.execute(
                """INSERT INTO projects (id, owner_id, title, description, aspect_ratio, resolution, frame_rate)
                   VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING""",
                uuid.UUID(PROJECT_ID), uuid.UUID(OWNER_ID),
                "The Courier of Carthage",
                "A lone courier crosses a desert empire to deliver a message that could prevent war. Visual style: Denis Villeneuve + Caravaggio, 35mm anamorphic, dust and gold.",
                "2.39:1", "4K", 24
            )
            print("Created demo project")

        # Upsert panels
        for p in panels:
            try:
                await conn.execute(
                    """INSERT INTO panels (id, project_id, ordinal, slug, prompt, negative_prompt, motion_prompt, camera, duration_seconds, reference_stack, continuity_state, locked, status)
                       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
                       ON CONFLICT (project_id, ordinal) DO UPDATE SET
                         prompt=EXCLUDED.prompt,
                         motion_prompt=EXCLUDED.motion_prompt,
                         camera=EXCLUDED.camera,
                         duration_seconds=EXCLUDED.duration_seconds,
                         slug=EXCLUDED.slug""",
                    uuid.UUID(p["id"]), uuid.UUID(p["project_id"]), p["ordinal"], p["slug"], p["prompt"],
                    p.get("negative_prompt",""), p.get("motion_prompt",""), p.get("camera","static"),
                    p.get("duration_seconds",3.0),
                    json.dumps(p.get("reference_stack",[])),
                    json.dumps(p.get("continuity_state",{})),
                    p.get("locked", False),
                    p.get("status","draft")
                )
            except Exception as e:
                print(f"Failed to insert panel {p.get('panelId')}: {e}")

        total = await conn.fetchval("SELECT COUNT(*) FROM panels WHERE project_id=$1", uuid.UUID(PROJECT_ID))
        print(f"Seed complete: {total} panels in project {PROJECT_ID}")

    await pool.close()
    return True

async def seed_via_http():
    import httpx
    api = os.environ.get("API_URL", "http://localhost:8000")
    panels_path = find_panels_file()
    panels = json.loads(panels_path.read_text())
    print(f"Seeding via HTTP {api} with {len(panels)} panels")

    async with httpx.AsyncClient(timeout=30) as c:
        # Try to create project via gateway if needed
        try:
            r = await c.get(f"{api}/api/project/projects/{PROJECT_ID}")
            if r.status_code == 404:
                # create
                await c.post(f"{api}/api/project/projects", json={
                    "title": "The Courier of Carthage",
                    "description": "A lone courier crosses a desert empire",
                    "aspectRatio": "2.39:1",
                    "resolution": "4K",
                    "frameRate": 24,
                    "ownerId": OWNER_ID
                })
        except Exception as e:
            print(f"Project check failed: {e}")

        # Create panels via project service
        for p in panels:
            try:
                await c.post(f"{api}/api/project/projects/{PROJECT_ID}/panels", json={
                    "ordinal": p["ordinal"],
                    "prompt": p["prompt"],
                    "negative_prompt": p.get("negative_prompt",""),
                    "motion_prompt": p.get("motion_prompt",""),
                    "camera": p.get("camera","static"),
                    "duration_seconds": p.get("duration_seconds",3.0),
                    "reference_stack": p.get("reference_stack",[])
                })
            except Exception as e:
                print(f"HTTP panel create failed {p['panelId']}: {e}")

    print("HTTP seed done")

async def main():
    print("☾ Lunara Studio — Seeding The Courier of Carthage")
    ok = await seed_via_db()
    if not ok:
        await seed_via_http()
    print("Done. Open http://localhost:3000/studio?project=demo")

if __name__ == "__main__":
    asyncio.run(main())

/**
 * Lunara Studio · API Gateway
 * Routes /api/:service/* to the corresponding microservice.
 * Handles CORS, request logging, and auth token forwarding.
 */
import Fastify from 'fastify';
import cors from '@fastify/cors';
import { request } from 'undici';

const app = Fastify({ logger: true });

const SERVICES: Record<string, string> = {
  auth:       process.env.AUTH_URL       ?? 'http://auth:8000',
  project:    process.env.PROJECT_URL    ?? 'http://project:8000',
  asset:      process.env.ASSET_URL      ?? 'http://asset:8000',
  canvas:     process.env.CANVAS_URL     ?? 'http://canvas:8000',
  repaint:    process.env.REPAINT_URL    ?? 'http://repaint:8000',
  av_motion:  process.env.AV_MOTION_URL  ?? 'http://av_motion:8000',
  motion:     process.env.AV_MOTION_URL  ?? 'http://av_motion:8000',
  sound:      process.env.SOUND_URL      ?? 'http://sound:8000',
  continuity: process.env.CONTINUITY_URL ?? 'http://continuity:8000',
  latent:     process.env.LATENT_URL     ?? 'http://latent:8000',
  film:       process.env.FILM_URL       ?? 'http://film:8000',
  render:     process.env.RENDER_URL     ?? 'http://render:8000',
};

await app.register(cors, { origin: true, credentials: true });

app.get('/health', async () => ({
  ok: true,
  service: 'gateway',
  version: '1.0.0',
  upstreams: Object.keys(SERVICES),
  timestamp: new Date().toISOString()
}));

app.get('/', async () => ({
  name: 'Lunara Studio Gateway',
  version: '1.0.0',
  docs: '/health',
  services: SERVICES
}));

// Proxy all /api/:service/* requests to the matching upstream.
app.all('/api/:service/*', async (req, reply) => {
  const { service } = req.params as { service: string };
  const upstream = SERVICES[service];
  if (!upstream) {
    return reply.code(404).send({ error: `Unknown service: ${service}`, known: Object.keys(SERVICES) });
  }

  const path = (req.params as Record<string, string>)['*'] ?? '';
  const url = `${upstream}/${path}`;
  const query = new URLSearchParams(req.query as Record<string, string>);
  const fullUrl = query.toString() ? `${url}?${query}` : url;

  const headers: Record<string, string> = {
    'content-type': req.headers['content-type'] ?? 'application/json',
  };
  if (req.headers.authorization) {
    headers.authorization = req.headers.authorization;
  }

  try {
    const response = await request(fullUrl, {
      method: req.method as any,
      headers,
      body: ['GET', 'HEAD'].includes(req.method) ? undefined : JSON.stringify(req.body),
    });

    const body = await response.body.text();
    reply
      .code(response.statusCode)
      .header('content-type', response.headers['content-type'] ?? 'application/json')
      .send(body);
  } catch (err) {
    req.log.error({ err, url: fullUrl }, 'proxy failed');
    reply.code(502).send({ error: 'Upstream unavailable', upstream, url: fullUrl });
  }
});

// Also support direct /api/:service without trailing slash
app.all('/api/:service', async (req, reply) => {
  const { service } = req.params as { service: string };
  const upstream = SERVICES[service];
  if (!upstream) {
    return reply.code(404).send({ error: `Unknown service: ${service}` });
  }
  const query = new URLSearchParams(req.query as Record<string, string>);
  const fullUrl = query.toString() ? `${upstream}?${query}` : upstream;

  const headers: Record<string, string> = {
    'content-type': req.headers['content-type'] ?? 'application/json',
  };
  if (req.headers.authorization) {
    headers.authorization = req.headers.authorization;
  }

  try {
    const response = await request(fullUrl, {
      method: req.method as any,
      headers,
      body: ['GET', 'HEAD'].includes(req.method) ? undefined : JSON.stringify(req.body),
    });
    const body = await response.body.text();
    reply.code(response.statusCode).header('content-type', response.headers['content-type'] ?? 'application/json').send(body);
  } catch (err) {
    req.log.error({ err, url: fullUrl }, 'proxy failed');
    reply.code(502).send({ error: 'Upstream unavailable' });
  }
});

const port = Number(process.env.PORT ?? 8000);
app.listen({ port, host: '0.0.0.0' }, (err) => {
  if (err) { app.log.error(err); process.exit(1); }
  app.log.info(`gateway listening on :${port}`);
});

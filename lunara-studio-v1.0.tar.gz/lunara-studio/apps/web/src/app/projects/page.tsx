'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export default function ProjectsPage() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${API}/api/project/projects`).then(r=>r.json()).then(d=>{
      setProjects(d.projects ?? []);
      setLoading(false);
    }).catch(()=>setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 p-8">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-light">Projects</h1>
          <Link href="/studio" className="px-4 py-2 bg-indigo-600 rounded-lg text-sm">Open Studio</Link>
        </div>
        {loading && <p className="text-zinc-500">Loading…</p>}
        <div className="grid gap-4">
          {projects.map(p=>(
            <div key={p.id} className="border border-zinc-800 rounded-lg p-6 hover:border-zinc-700 bg-zinc-900/30">
              <div className="flex justify-between">
                <div>
                  <h2 className="text-xl">{p.title}</h2>
                  <p className="text-sm text-zinc-500 mt-1">{p.description}</p>
                  <div className="flex gap-3 mt-3 text-xs text-zinc-600 font-mono">
                    <span>{p.aspectRatio}</span><span>{p.resolution}</span><span>{p.frameRate}fps</span>
                  </div>
                </div>
                <Link href={`/studio?project=${p.id}`} className="h-fit px-4 py-2 border border-zinc-700 rounded-lg text-sm hover:bg-zinc-900">Open</Link>
              </div>
            </div>
          ))}
        </div>
        {!loading && projects.length===0 && <p className="text-zinc-600">No projects. Run make seed.</p>}
      </div>
    </div>
  );
}

'use client';
import { useState, useEffect } from 'react';
import { Sidebar } from '@/components/Sidebar';
import { PanelBoard } from '@/components/PanelBoard';
import { CanvasPanel } from '@/components/CanvasPanel';
import { MotionPanel } from '@/components/MotionPanel';
import { SoundPanel } from '@/components/SoundPanel';
import { JobDock } from '@/components/JobDock';
import { TopBar } from '@/components/TopBar';
import { FilmPanel } from '@/components/FilmPanel';

type Module = 'panels' | 'canvas' | 'motion' | 'sound' | 'film' | 'library';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export default function Studio() {
  const [mod, setMod] = useState<Module>('panels');
  const [panel, setPanel] = useState<string | null>(null);
  const [panels, setPanels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [projectId, setProjectId] = useState('demo');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pid = params.get('project') || 'demo';
    setProjectId(pid);
    fetch(`${API}/api/project/projects/${pid}/panels`)
      .then(r => r.json())
      .then(d => { setPanels(d.panels ?? []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const selectedPanel = panels.find(p => p.id === panel || p.panelId === panel) || panels[0];

  return (
    <div className="h-screen flex flex-col bg-zinc-950 text-zinc-100">
      <TopBar projectId={projectId} panelCount={panels.length} />
      <div className="flex-1 flex overflow-hidden">
        <Sidebar active={mod} onNav={(id)=>setMod(id as Module)} />
        <main className="flex-1 overflow-auto p-6 bg-zinc-950">
          {loading && <p className="text-zinc-500">Loading panels…</p>}
          {!loading && mod === 'panels' && (
            <PanelBoard panels={panels} onSelect={(id)=>{ setPanel(id); setMod('canvas'); }} />
          )}
          {!loading && mod === 'canvas' && (
            <CanvasPanel panelId={selectedPanel?.id ?? 'P1-01'} panel={selectedPanel} />
          )}
          {!loading && mod === 'motion' && (
            <MotionPanel panelId={selectedPanel?.id ?? 'P1-01'} panel={selectedPanel} />
          )}
          {!loading && mod === 'sound' && (
            <SoundPanel panelId={selectedPanel?.id ?? 'P1-01'} panel={selectedPanel} />
          )}
          {!loading && mod === 'film' && (
            <FilmPanel projectId={projectId} panels={panels} />
          )}
          {mod === 'library' && (
            <div className="space-y-4">
              <h2 className="text-2xl font-light">Asset Library</h2>
              <p className="text-zinc-500 text-sm">Assets are stored in MinIO (S3 compatible). Browse at http://localhost:9001</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                {panels.slice(0,8).map((p:any)=>(
                  <div key={p.id} className="aspect-video bg-zinc-900 rounded border border-zinc-800 flex items-center justify-center text-xs text-zinc-600">
                    {p.keyframeUrl ? <img src={p.keyframeUrl} alt={p.panelId} className="w-full h-full object-cover rounded" /> : 'No asset'}
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
      <JobDock />
    </div>
  );
}

import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Lunara Studio — AI Film Production',
  description: 'Complete, Free, Self-Hostable AI Film Production Platform',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-zinc-950 text-zinc-100 antialiased min-h-screen">{children}</body>
    </html>
  );
}

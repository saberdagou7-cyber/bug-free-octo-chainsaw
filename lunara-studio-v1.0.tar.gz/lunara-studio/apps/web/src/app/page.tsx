import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center gap-8 p-8 bg-zinc-950 text-zinc-100">
      <div className="text-center space-y-4 max-w-2xl">
        <h1 className="text-7xl font-light tracking-tight">
          ☾ Lunara
        </h1>
        <p className="text-2xl text-zinc-300 font-light">
          From a single idea to a finished film.
        </p>
        <p className="text-sm text-zinc-500 leading-relaxed">
          Complete, Free, Self-Hostable AI Film Production Platform.<br/>
          Open-weight models: SDXL, Flux, LTX-2.5, Wan 2.2, MiniMax H3, Qwen3-TTS, ACE-Step.<br/>
          No paid APIs. No proprietary services. Docker Compose boots the full stack.
        </p>
      </div>

      <div className="flex gap-4">
        <Link
          href="/studio"
          className="px-8 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 transition-colors font-medium"
        >
          Open Studio →
        </Link>
        <Link
          href="/projects"
          className="px-8 py-3 rounded-lg border border-zinc-700 hover:border-zinc-500 hover:bg-zinc-900 transition-colors"
        >
          Projects
        </Link>
      </div>

      <div className="grid grid-cols-3 gap-4 max-w-3xl w-full mt-8 text-xs">
        <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/50">
          <div className="text-zinc-400 mb-1">Canvas (T2I)</div>
          <div className="text-white font-mono">SDXL 1.0 / Flux</div>
          <div className="text-zinc-600 mt-1">Apache 2.0 · Free</div>
        </div>
        <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/50">
          <div className="text-zinc-400 mb-1">A/V Motion (I2V)</div>
          <div className="text-white font-mono">LTX-2.5 / Wan 2.2 / H3</div>
          <div className="text-zinc-600 mt-1">4K @ 50fps · Free</div>
        </div>
        <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/50">
          <div className="text-zinc-400 mb-1">Sound</div>
          <div className="text-white font-mono">Qwen3-TTS / ACE-Step</div>
          <div className="text-zinc-600 mt-1">Apache 2.0 · 4GB VRAM</div>
        </div>
      </div>

      <p className="text-xs text-zinc-600 max-w-md text-center mt-4">
        The Courier of Carthage ships as the demo project.<br/>
        Run <code className="text-zinc-400 bg-zinc-900 px-1.5 py-0.5 rounded">make seed</code> to load it.<br/>
        <span className="mt-2 block">Web: localhost:3000 · API: localhost:8000 · MinIO: localhost:9001</span>
      </p>
    </main>
  );
}

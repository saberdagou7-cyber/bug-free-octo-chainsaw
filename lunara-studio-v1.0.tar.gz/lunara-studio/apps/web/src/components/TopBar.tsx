'use client';

export function TopBar({ projectId, panelCount }: { projectId?: string, panelCount?: number }) {
  return (
    <header className="h-14 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-950">
      <div className="flex items-center gap-3">
        <span className="text-lg">☾</span>
        <span className="font-medium">Lunara Studio</span>
        <span className="text-xs text-zinc-500 ml-2">v1.0 · free · self-hostable</span>
      </div>
      <div className="flex items-center gap-4 text-sm text-zinc-400">
        <span className="hidden md:inline">{projectId === 'demo' || projectId?.includes('00000000') ? 'The Courier of Carthage' : projectId}</span>
        {panelCount !== undefined && <span className="text-xs text-zinc-600 font-mono">{panelCount} panels</span>}
        <span className="text-xs text-zinc-600 font-mono hidden md:inline">SDXL · LTX-2.5 · H3 · Qwen3-TTS · ACE-Step</span>
      </div>
    </header>
  );
}

'use client';
import { useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function JobDock() {
  const [jobs, setJobs] = useState<any[]>([]);
  const [health, setHealth] = useState<any>(null);

  useEffect(()=>{
    fetch(`${API}/health`).then(r=>r.json()).then(setHealth).catch(()=>{});
    const id = setInterval(()=>{
      fetch(`${API}/api/film/pipeline`).then(r=>r.json()).then(d=>setJobs(d.jobs || [])).catch(()=>{});
    }, 3000);
    return ()=>clearInterval(id);
  }, []);

  const active = jobs.filter(j=>j.status==='running' || j.status==='queued');

  return (
    <footer className="h-12 border-t border-zinc-800 flex items-center px-6 text-xs text-zinc-500 bg-zinc-950 justify-between">
      <div className="flex items-center gap-4">
        <span className="font-mono">JOBS: {active.length ? `${active.length} active` : 'No active jobs'}</span>
        {active.map(j=>(
          <span key={j.job_id} className="text-zinc-400">{j.job_id?.slice(0,8)} · {j.completed_panels}/{j.total_panels}</span>
        ))}
      </div>
      <div className="flex items-center gap-3 font-mono">
        <span className={health?.ok ? 'text-green-600' : 'text-zinc-600'}>● gateway {health?.ok ? 'ok' : '…'}</span>
        <span className="text-zinc-700 hidden md:inline">14 services · mock adapters · MinIO · Postgres · Redis</span>
      </div>
    </footer>
  );
}

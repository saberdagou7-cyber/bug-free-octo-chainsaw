'use client';

export function ContinuityBadge({ score, passed }: { score: number, passed: boolean }) {
  return (
    <span className={`px-2 py-0.5 rounded text-[10px] font-mono ${passed ? 'bg-green-900/50 text-green-300 border border-green-800' : 'bg-red-900/50 text-red-300 border border-red-800'}`}>
      {passed ? '✓' : '✗'} {score.toFixed(2)}
    </span>
  );
}

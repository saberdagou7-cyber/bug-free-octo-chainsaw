'use client';
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function FilmPanel({ projectId, panels }: { projectId: string, panels: any[] }) {
  const [job, setJob] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [steps, setSteps] = useState<string[]>(['canvas','motion']);

  async function run() {
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/film/pipeline/run`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ project_id: projectId, steps, canvas_variants: 1, resolution: '720p' })
      });
      const d = await r.json();
      setJob(d);
      // poll
      const jobId = d.jobId;
      const interval = setInterval(async ()=>{
        const s = await fetch(`${API}/api/film/pipeline/${jobId}`).then(r=>r.json());
        setJob(s);
        if (s.status === 'completed' || s.status === 'failed') clearInterval(interval);
      }, 2000);
    } catch(e){console.error(e);} finally{setLoading(false);}
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <h2 className="text-2xl font-light">Film Pipeline — Orchestrator</h2>
      <p className="text-sm text-zinc-500">Runs canvas → repaint → av_motion → sound → render. Mock adapters produce real bytes through asset → latent → continuity.</p>

      <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/30 space-y-4">
        <div className="text-xs font-mono text-zinc-400">STEPS</div>
        <div className="flex gap-2 flex-wrap">
          {['canvas','repaint','motion','sound','render'].map(s=>(
            <label key={s} className="flex items-center gap-2 text-sm border border-zinc-800 rounded-lg px-3 py-2 cursor-pointer hover:border-zinc-700">
              <input type="checkbox" checked={steps.includes(s)} onChange={e=>{
                if (e.target.checked) setSteps([...steps, s]);
                else setSteps(steps.filter(x=>x!==s));
              }} />
              {s}
            </label>
          ))}
        </div>
        <div className="text-xs text-zinc-600">{panels.length} panels · {panels.reduce((a:any,b:any)=>a+(b.duration_seconds||3),0)}s total · {projectId}</div>
        <button onClick={run} disabled={loading} className="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-sm font-medium">
          {loading ? 'Queuing…' : 'Run Pipeline'}
        </button>
      </div>

      {job && (
        <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/50 space-y-3">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-indigo-400">{job.job_id || job.jobId}</span>
            <span className={`${job.status==='completed' ? 'text-green-400' : job.status==='failed' ? 'text-red-400' : 'text-yellow-400'}`}>{job.status}</span>
          </div>
          <div className="text-xs text-zinc-500">Progress: {job.completed_panels || 0}/{job.total_panels || panels.length}</div>
          {job.results && (
            <div className="space-y-2 max-h-96 overflow-auto">
              {job.results.map((r:any,i:number)=>(
                <div key={i} className="text-xs border border-zinc-800 rounded p-2">
                  <div className="font-mono text-zinc-300">Panel {r.ordinal || i+1} · {r.panel_id}</div>
                  <div className="text-zinc-500 mt-1">{Object.keys(r.steps || {}).join(', ')}</div>
                  {r.steps?.motion?.result?.url && <div className="text-zinc-600 truncate">{r.steps.motion.result.url}</div>}
                </div>
              ))}
            </div>
          )}
          {job.render && (
            <div className="border-t border-zinc-800 pt-3">
              <div className="text-xs font-mono text-zinc-400">RENDER OUTPUT</div>
              <div className="text-xs text-zinc-300 mt-1 break-all">{job.render.outputPath || job.render.outputUrl || JSON.stringify(job.render)}</div>
            </div>
          )}
          {job.error && <div className="text-xs text-red-400">{job.error}</div>}
        </div>
      )}

      <div className="text-[11px] text-zinc-600 font-mono">
        Film service calls canvas, repaint, av_motion, sound, continuity, latent, render.<br/>
        With mock adapters, full pipeline runs end-to-end without external services. Artifacts land in MinIO, get embedded, pass/fail continuity.
      </div>
    </div>
  );
}

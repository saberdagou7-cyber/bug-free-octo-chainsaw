'use client';

export function PanelBoard({
  panels, onSelect,
}: {
  panels: any[];
  onSelect: (id: string) => void;
}) {
  if (!panels.length) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-light">Panels</h2>
        <p className="text-zinc-500">No panels loaded. Run make seed or create a project.</p>
        <div className="border border-dashed border-zinc-800 rounded-lg p-12 text-center">
          <p className="text-zinc-600">The Courier of Carthage — 10 panels · 2.39:1 · 4K · 24fps</p>
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-light">Panels — {panels.length} shots</h2>
        <div className="text-xs text-zinc-500 font-mono">{panels.reduce((a:any,b:any)=>a+(b.duration_seconds||3),0).toFixed(1)}s total</div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {panels.map((p) => (
          <button
            key={p.id || p.panelId}
            onClick={() => onSelect(p.id || p.panelId)}
            className="text-left rounded-lg border border-zinc-800 hover:border-indigo-500 overflow-hidden transition-colors bg-zinc-900/30 group"
          >
            <div className="aspect-video bg-zinc-900 flex items-center justify-center relative overflow-hidden">
              {p.keyframeUrl || p.keyframe_url ? (
                <img src={p.keyframeUrl || p.keyframe_url} alt={p.panelId} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <span className="text-zinc-700 text-xs">No keyframe</span>
                  <span className="text-[10px] text-zinc-600 font-mono">{p.slug}</span>
                </div>
              )}
              <div className="absolute top-2 left-2 bg-black/70 px-2 py-0.5 rounded text-[10px] font-mono text-indigo-300">{p.panelId || `P${p.ordinal}`}</div>
              <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-0.5 rounded text-[10px] font-mono text-zinc-300">{p.duration_seconds || 3}s · {p.camera || 'static'}</div>
            </div>
            <div className="p-3">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs text-indigo-400">{p.panelId || p.slug}</span>
                <span className="text-xs text-zinc-500">{p.status || 'draft'}</span>
              </div>
              <p className="mt-1 text-sm text-zinc-300 line-clamp-2 leading-snug">{p.prompt}</p>
              {p.motion_prompt && <p className="mt-1 text-xs text-zinc-500 line-clamp-1">↳ {p.motion_prompt}</p>}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

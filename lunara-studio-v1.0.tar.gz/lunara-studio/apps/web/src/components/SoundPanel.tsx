'use client';
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function SoundPanel({ panelId, panel }: { panelId: string, panel?: any }) {
  const [kind, setKind] = useState<'dialogue'|'score'|'ambience'|'foley'>('dialogue');
  const [prompt, setPrompt] = useState('A weary courier whispers: The seal must reach Carthage before dawn.');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function generate() {
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/sound/generate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ kind, prompt, duration_ms: 5000, voice_id: 'default' })
      });
      const d = await r.json();
      setResult(d.result);
    } catch(e){console.error(e);} finally{setLoading(false);}
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <h2 className="text-2xl font-light">Sound — {panel?.panelId || panelId}</h2>
      <p className="text-sm text-zinc-500">TTS via Qwen3-TTS (3-sec cloning, Apache 2.0) + Music via ACE-Step 1.5 (consumer GPU, &lt;4GB VRAM). Runs at final mix.</p>

      <div className="flex gap-2">
        {(['dialogue','score','ambience','foley'] as const).map(k=>(
          <button key={k} onClick={()=>setKind(k)} className={`px-4 py-2 rounded-lg text-sm border ${kind===k ? 'bg-indigo-600 border-indigo-500 text-white' : 'border-zinc-800 text-zinc-400 hover:border-zinc-700'}`}>{k}</button>
        ))}
      </div>

      <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={3} className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 text-sm focus:border-indigo-500 focus:outline-none" placeholder="Enter dialogue, score description, or foley prompt..." />

      <button onClick={generate} disabled={loading || !prompt} className="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-sm font-medium">
        {loading ? 'Generating…' : `Generate ${kind}`}
      </button>

      {result && (
        <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/50 space-y-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-indigo-400">{result.adapter}</span>
            <span className="text-zinc-500">{result.kind} · {result.durationMs}ms</span>
          </div>
          <div className="text-xs text-zinc-400 break-all">{result.url}</div>
          <audio controls src={result.url.startsWith('mock://') ? undefined : result.url} className="w-full mt-2" />
          {result.url.startsWith('mock://') && <div className="text-xs text-zinc-600">Mock audio — connect Qwen3-TTS at {process.env.NEXT_PUBLIC_API_URL || 'localhost:8191'} for real TTS</div>}
        </div>
      )}
    </div>
  );
}

'use client';
import { useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function CanvasPanel({ panelId, panel }: { panelId: string, panel?: any }) {
  const [prompt, setPrompt] = useState(panel?.prompt || '');
  const [variants, setVariants] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [adapter, setAdapter] = useState('mock');

  async function generate() {
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/canvas/generate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ prompt, variants: 4, width: 1024, height: 576 }),
      });
      const d = await r.json();
      setVariants(d.variants ?? []);
      setAdapter(d.adapter ?? 'mock');
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="text-2xl font-light">Canvas — {panel?.panelId || panelId}</h2>
        <p className="text-sm text-zinc-500 mt-1">T2I generation via {adapter} · SDXL 1.0 / Flux · Free, self-hosted, Apache 2.0</p>
      </div>

      <div className="flex gap-2">
        <input
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the frame… e.g. Wide desert at dawn, golden light, lone figure on horseback"
          className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 text-sm focus:border-indigo-500 focus:outline-none"
        />
        <button
          onClick={generate}
          disabled={loading || !prompt}
          className="px-6 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-sm font-medium transition-colors"
        >
          {loading ? 'Generating…' : 'Generate ×4'}
        </button>
      </div>

      {panel && (
        <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/30 text-xs space-y-2">
          <div className="text-zinc-400 font-mono">PANEL META</div>
          <div className="grid grid-cols-2 gap-2 text-zinc-300">
            <div>Camera: <span className="text-white">{panel.camera || 'static'}</span></div>
            <div>Duration: <span className="text-white">{panel.duration_seconds || 3}s</span></div>
            <div>Motion: <span className="text-zinc-400">{panel.motion_prompt || '—'}</span></div>
            <div>Status: <span className="text-white">{panel.status || 'draft'}</span></div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        {variants.map((v, i) => (
          <div key={i} className="aspect-video bg-zinc-900 rounded-lg overflow-hidden border border-zinc-800 group relative">
            <img src={v.url} alt={`variant ${i}`} className="w-full h-full object-cover" />
            <div className="absolute bottom-0 left-0 right-0 bg-black/70 p-2 text-[10px] font-mono text-zinc-400 opacity-0 group-hover:opacity-100 transition-opacity">
              {v.adapter_name} · {v.resolution} · {v.url.slice(0,60)}…
            </div>
          </div>
        ))}
        {!variants.length && (
          <>
            {[0,1,2,3].map(i=>(
              <div key={i} className="aspect-video bg-zinc-900 rounded-lg border border-dashed border-zinc-800 flex items-center justify-center text-zinc-700 text-xs">
                Variant {i+1} — will appear here
              </div>
            ))}
          </>
        )}
      </div>

      <div className="text-[11px] text-zinc-600 font-mono border-t border-zinc-800 pt-4">
        Free adapters: mock (PIL placeholder, no GPU) · sdxl (SDXL 1.0, OpenRAIL++) · flux (Flux, Apache 2.0).<br/>
        Set CANVAS_ADAPTER=sdxl and SDXL_API_URL=http://your-comfyui:8188 in .env to go live. No API keys.
      </div>
    </div>
  );
}

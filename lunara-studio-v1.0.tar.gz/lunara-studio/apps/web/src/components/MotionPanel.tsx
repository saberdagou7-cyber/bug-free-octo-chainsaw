'use client';
import { useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function MotionPanel({ panelId, panel }: { panelId: string, panel?: any }) {
  const [motionPrompt, setMotionPrompt] = useState(panel?.motion_prompt || 'slow push in, dust particles, subtle wind');
  const [camera, setCamera] = useState(panel?.camera || 'push_in');
  const [duration, setDuration] = useState(panel?.duration_seconds || 3);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [adapter, setAdapter] = useState('mock');

  async function generate() {
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/av_motion/generate`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          source_url: panel?.keyframeUrl || panel?.keyframe_url || 'mock://canvas/test.png',
          motion_prompt: motionPrompt,
          camera_movement: camera,
          duration,
          resolution: '720p',
          aspect_ratio: '16:9',
          frame_rate: 24,
        }),
      });
      const d = await r.json();
      setResult(d.result);
      setAdapter(d.adapter);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="text-2xl font-light">Motion — {panel?.panelId || panelId}</h2>
        <p className="text-sm text-zinc-500 mt-1">I2V generation via {adapter} · LTX-2.5 (joint A/V, free under $10M ARR) / Wan 2.2 (Apache 2.0) / MiniMax H3 (2K + stereo)</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 space-y-3">
          <label className="text-xs text-zinc-400 font-mono">MOTION PROMPT</label>
          <input value={motionPrompt} onChange={e=>setMotionPrompt(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 text-sm focus:border-indigo-500 focus:outline-none" />
        </div>
        <div className="space-y-3">
          <label className="text-xs text-zinc-400 font-mono">CAMERA</label>
          <select value={camera} onChange={e=>setCamera(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-3 text-sm">
            <option value="static">static</option>
            <option value="push_in">push_in</option>
            <option value="pull_out">pull_out</option>
            <option value="pan_left">pan_left</option>
            <option value="pan_right">pan_right</option>
            <option value="tilt_up">tilt_up</option>
            <option value="handheld">handheld</option>
            <option value="crane_up">crane_up</option>
          </select>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <label className="text-xs text-zinc-400">Duration</label>
          <input type="number" value={duration} onChange={e=>setDuration(parseFloat(e.target.value))} min={1} max={15} step={0.5} className="w-20 bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-sm" />
          <span className="text-xs text-zinc-500">s</span>
        </div>
        <button onClick={generate} disabled={loading} className="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-sm font-medium">
          {loading ? 'Generating…' : 'Generate Motion'}
        </button>
      </div>

      {result ? (
        <div className="border border-zinc-800 rounded-lg p-4 bg-zinc-900/50 space-y-3">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-indigo-400">{result.adapter_name}</span>
            <span className="text-zinc-500">{result.duration_seconds}s · {result.resolution} · {result.kind}</span>
          </div>
          <div className="aspect-video bg-black rounded flex items-center justify-center text-zinc-600 text-sm">
            {result.url.startsWith('mock://') ? `Mock video: ${result.url}` : <video src={result.url} controls className="w-full h-full rounded" />}
          </div>
          <div className="text-[11px] text-zinc-500 font-mono break-all">{result.url}</div>
          {result.audio_url && <div className="text-[11px] text-zinc-500">Audio: {result.audio_url}</div>}
        </div>
      ) : (
        <div className="aspect-video bg-zinc-900 rounded-lg border border-dashed border-zinc-800 flex flex-col items-center justify-center gap-2 text-zinc-600">
          <span className="text-sm">Motion output will appear here</span>
          <span className="text-xs font-mono">Supports video reference, native audio, lip-sync (LTX/H3)</span>
        </div>
      )}

      <div className="text-[11px] text-zinc-600 font-mono border-t border-zinc-800 pt-4 space-y-1">
        <div>LTX-2.5: 6.8s per 10s clip on H100, 4K @ 50fps, joint A/V, free under $10M ARR.</div>
        <div>Wan 2.2: Apache 2.0, 720p @ 24fps, runs on 4090, video-only.</div>
        <div>MiniMax H3: open-sourced Aug 2026, 2K + native stereo, 2–15s, free commercial.</div>
      </div>
    </div>
  );
}

'use client';
import { Film, Image, Play, Music, Folder, Clapperboard } from 'lucide-react';
import clsx from 'clsx';

const items = [
  { id: 'panels',  label: 'Panels',  icon: Film, desc: 'Storyboard' },
  { id: 'canvas',  label: 'Canvas',  icon: Image, desc: 'T2I SDXL/Flux' },
  { id: 'motion',  label: 'Motion',  icon: Play, desc: 'LTX/Wan/H3' },
  { id: 'sound',   label: 'Sound',   icon: Music, desc: 'TTS & Score' },
  { id: 'film',    label: 'Film',    icon: Clapperboard, desc: 'Pipeline' },
  { id: 'library', label: 'Library', icon: Folder, desc: 'MinIO' },
] as const;

export function Sidebar({
  active, onNav,
}: {
  active: string;
  onNav: (id: string) => void;
}) {
  return (
    <aside className="w-56 border-r border-zinc-800 flex flex-col bg-zinc-950">
      <div className="p-4 border-b border-zinc-800">
        <div className="text-xs text-zinc-500 font-mono">MODULES</div>
      </div>
      {items.map(({ id, label, icon: Icon, desc }) => (
        <button
          key={id}
          onClick={() => onNav(id)}
          className={clsx(
            'flex items-center gap-3 px-4 py-3 text-sm transition-colors text-left',
            active === id
              ? 'bg-zinc-900 text-white border-l-2 border-indigo-500'
              : 'text-zinc-400 hover:text-white hover:bg-zinc-900/50 border-l-2 border-transparent',
          )}
        >
          <Icon size={16} />
          <div className="flex flex-col">
            <span>{label}</span>
            <span className="text-[10px] text-zinc-600">{desc}</span>
          </div>
        </button>
      ))}
      <div className="mt-auto p-4 border-t border-zinc-800 text-[10px] text-zinc-600 font-mono">
        <div>ADAPTERS: mock (default)</div>
        <div className="mt-1">FREE · SELF-HOSTED</div>
        <div className="mt-2 text-zinc-500">SDXL · Flux · LTX-2.5<br/>Wan 2.2 · H3 · Qwen3-TTS<br/>ACE-Step · FFmpeg</div>
      </div>
    </aside>
  );
}
